// CallHub service worker: tarpininkas tarp puslapio/skydelio ir vietinio serverio.
const HUB = "http://127.0.0.1:8199";

// Paspaudus įrankio ikoną — atidaryti šoninį skydelį (jis lieka atidarytas
// dirbant su puslapiu, skirtingai nei popup, kuris užsidaro praradus fokusą).
if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
}

async function dial(number) {
  const r = await fetch(HUB + "/dial", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ number })
  });
  return r.json();
}

async function hangup() {
  const r = await fetch(HUB + "/hangup", { method: "POST" });
  return r.json();
}

// ---- AI: naudojam VIENĄ chatą (tą patį tab'ą), kad nesikauptų daug pokalbių ----
function aiBase(provider) {
  if (provider === "claude") return "https://claude.ai/new";
  if (provider === "gemini") return "https://gemini.google.com/app";
  return "https://chatgpt.com/";
}

// Tab'ą sekam KIEKVIENAM modeliui atskirai (kad grįžus prie modelio reuse'intų jo langą)
async function getTabs() {
  const { aiTabs } = await chrome.storage.session.get("aiTabs");
  return aiTabs || {};
}
async function setTab(provider, id) {
  const tabs = await getTabs();
  tabs[provider] = id;
  await chrome.storage.session.set({ aiTabs: tabs });
}
async function clearTab(provider) {
  const tabs = await getTabs();
  delete tabs[provider];
  await chrome.storage.session.set({ aiTabs: tabs });
}

function waitForComplete(tabId, timeout = 15000) {
  return new Promise((resolve) => {
    const t = setTimeout(() => { chrome.tabs.onUpdated.removeListener(cb); resolve(false); }, timeout);
    function cb(id, info) {
      if (id === tabId && info.status === "complete") {
        clearTimeout(t); chrome.tabs.onUpdated.removeListener(cb); resolve(true);
      }
    }
    chrome.tabs.onUpdated.addListener(cb);
  });
}

async function aiImprove(prompt, provider, forceNew) {
  const tabs = await getTabs();
  let tab = null;
  // Naudojam ŠIO modelio tab'ą, jei jis gyvas
  if (!forceNew && tabs[provider] != null) {
    try { tab = await chrome.tabs.get(tabs[provider]); } catch (e) { tab = null; }
  }
  if (tab) {
    try {
      const res = await chrome.tabs.sendMessage(tab.id, { type: "callhub-insert", text: prompt });
      return { ok: true, injected: !!(res && res.ok), reused: true };
    } catch (e) {
      // tab'as dingo arba be skripto — krentam žemyn ir kuriam naują
    }
  }
  // Naujas tab'as FONE (naujas šio modelio chatas)
  const created = await chrome.tabs.create({ url: aiBase(provider), active: false });
  await setTab(provider, created.id);
  await waitForComplete(created.id);
  await new Promise((r) => setTimeout(r, 2500)); // palaukiam kol SPA atsivaizduos (fone – ilgiau)
  try {
    const res = await chrome.tabs.sendMessage(created.id, { type: "callhub-insert", text: prompt });
    return { ok: true, injected: !!(res && res.ok), reused: false };
  } catch (e) {
    return { ok: true, injected: false, reused: false };
  }
}

async function aiOpen(provider) {
  const tabs = await getTabs();
  if (tabs[provider] != null) {
    try {
      const tab = await chrome.tabs.get(tabs[provider]);
      await chrome.tabs.update(tab.id, { active: true });
      try { await chrome.windows.update(tab.windowId, { focused: true }); } catch (e) {}
      return { ok: true, existed: true };
    } catch (e) { /* dingo */ }
  }
  const created = await chrome.tabs.create({ url: aiBase(provider), active: true });
  await setTab(provider, created.id);
  return { ok: true, existed: false };
}

// ---- Pre-call DI planas: iš skelbimo + istorijos + cheatsheet -> AI planas ----
async function getCalls() {
  try { const r = await fetch(HUB + "/calls"); return await r.json(); } catch (e) { return []; }
}
function digitsOnly(s) { return String(s || "").replace(/\D/g, ""); }
function matchHistory(calls, phone) {
  const pd = digitsOnly(phone).slice(-8);
  if (!pd) return [];
  return (calls || []).filter(c => digitsOnly(c.number).slice(-8) === pd);
}
function buildPreCallPrompt(data, hist, objections) {
  let h;
  if (hist && hist.length) {
    const last = hist[0];
    h = "ISTORIJA su šiuo savininku: " + hist.length + " ankstesnis(-i) skambutis(-iai). Paskutinis — "
      + (last.transcribed_at || "?") + ".\nPaskutinio pokalbio santrauka: "
      + ((last.transcript || "").slice(0, 700) || "(teksto nėra)");
  } else {
    h = "ISTORIJA: su šiuo savininku dar nekalbėta (pirmas kontaktas).";
  }
  let obj = "";
  try {
    const all = [].concat((objections && objections.pardavimas) || [], (objections && objections.nuoma) || [])
      .filter(o => o && o.q).slice(0, 6);
    if (all.length) obj = "\n\nMANO TURIMI ATSAKYMAI Į PRIEŠTARAS (pritaikyk, jei tiks):\n"
      + all.map(o => "• „" + o.q + "“ → " + (o.a || "")).join("\n");
  } catch (e) {}
  return `Esu nekilnojamojo turto brokeris Lietuvoje. Ruošiuosi SKAMBINTI šio skelbimo savininkui — šaltas skambutis, bet ŠVELNUS: pradžioje pasidomiu (kaip sekasi, apie objektą), NE iš karto siūlau paslaugą.

SKELBIMAS (${data.url || ""}):
${data.title || ""}

${(data.text || "").slice(0, 3000)}

${h}${obj}

Paruošk TRUMPĄ, konkretų pokalbio planą LIETUVIŠKAI (be įžangų — iškart planas; tinka garsiai skaityti pokalbio metu):
1. ŠVELNUS ATIDARYMAS — 1–2 sakiniai, ne pardavimas (pasidomėk kaip sekasi / apie objektą).
2. 2–3 KLAUSIMAI apie motyvaciją, laiką, kainą (kad suprasčiau, ar realiai reikia pagalbos).
3. 2–3 TIKĖTINOS PRIEŠTAROS + trumpas atsakymas kiekvienai (pripažink → perfreimuok į VERTĘ, ne komisinį → klausimas).
4. KRYPTIS — realus kitas žingsnis (dažniausiai nemokamas įvertinimas ar trumpas susitikimas, NE mandatas iškart). Jei savininkas tvirtai nori parduoti pats — pasiūlyk savipardavimo kursą (tai ne pralaimėjimas).

Būk konkretus ŠIAM objektui (kaina, plotas, rajonas, kiek kabo). Mandagi, natūrali lietuvių kalba, jokių angliškų terminų.`;
}

async function precallPlan(data) {
  const [calls, store] = await Promise.all([
    getCalls(),
    chrome.storage.local.get(["objections", "ai"])
  ]);
  const hist = matchHistory(calls, data.phone);
  const prompt = buildPreCallPrompt(data, hist, store.objections);
  const provider = store.ai || "chatgpt";
  const res = await aiImprove(prompt, provider, false);
  // parodom AI langą priekyje, kad iškart matytų planą
  try { const t = (await getTabs())[provider]; if (t != null) await chrome.tabs.update(t, { active: true }); } catch (e) {}
  return { ok: true, injected: res.injected, history: hist.length };
}

// Iš content script'o (paspaudus numerį / „Baigti")
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "precallPlan") {
    precallPlan(msg)
      .then(res => sendResponse(res))
      .catch(err => sendResponse({ ok: false, error: String(err) }));
    return true; // async
  }
  if (msg && msg.type === "dial") {
    dial(msg.number)
      .then(res => sendResponse(res))
      .catch(err => sendResponse({ ok: false, error: String(err) }));
    return true; // async
  }
  if (msg && msg.type === "hangup") {
    hangup()
      .then(res => sendResponse(res))
      .catch(err => sendResponse({ ok: false, error: String(err) }));
    return true; // async
  }
  if (msg && msg.type === "aiImprove") {
    aiImprove(msg.prompt, msg.provider, msg.forceNew)
      .then(res => sendResponse(res))
      .catch(err => sendResponse({ ok: false, error: String(err) }));
    return true; // async
  }
  if (msg && msg.type === "aiNewChat") {
    chrome.storage.session.remove(["aiTabId", "aiProvider"])
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: true }));
    return true; // async
  }
  if (msg && msg.type === "aiOpen") {
    aiOpen(msg.provider)
      .then(res => sendResponse(res))
      .catch(err => sendResponse({ ok: false, error: String(err) }));
    return true; // async
  }
});

// Dešinio klik meniu ant pažymėto teksto
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "callhub-dial",
    title: "📞 Skambinti (Poco): %s",
    contexts: ["selection"]
  });
});

chrome.contextMenus.onClicked.addListener((info) => {
  if (info.menuItemId === "callhub-dial" && info.selectionText) {
    dial(info.selectionText).catch(() => {});
  }
});
