// CallHub AI įrašymas: gavęs promptą, įrašo jį į ChatGPT/Claude pokalbio laukelį
// ir išsiunčia. Best-effort — jei nepavyksta, side panel'is paprašo įklijuoti ranka.

(function () {
  function findComposer() {
    return document.querySelector("#prompt-textarea")
        || document.querySelector('div.ql-editor[contenteditable="true"]')       // Gemini
        || document.querySelector('rich-textarea div[contenteditable="true"]')    // Gemini (alt)
        || document.querySelector('div[contenteditable="true"].ProseMirror')       // ChatGPT / Claude
        || document.querySelector('div[contenteditable="true"]')
        || document.querySelector("textarea");
  }

  function findSendButton() {
    const sels = [
      'button[data-testid="send-button"]',   // ChatGPT
      'button[aria-label="Send prompt"]',
      'button[aria-label="Send message"]',   // Claude / Gemini
      'button.send-button',                   // Gemini
      'button[mattooltip*="Send"]',           // Gemini (alt)
      'button[aria-label*="Send"]',
      'button[aria-label*="Siųsti"]',
    ];
    for (const s of sels) {
      const b = document.querySelector(s);
      if (b && !b.disabled && b.getAttribute("aria-disabled") !== "true") return b;
    }
    return null;
  }

  function insertText(el, text) {
    el.focus();
    if (el.tagName === "TEXTAREA") {
      const setter = Object.getOwnPropertyDescriptor(
        window.HTMLTextAreaElement.prototype, "value").set;
      setter.call(el, text);
      el.dispatchEvent(new Event("input", { bubbles: true }));
    } else {
      // contenteditable (ProseMirror) — execCommand užregistruoja teisingus event'us
      try { document.execCommand("selectAll", false, null); } catch (e) {}
      document.execCommand("insertText", false, text);
    }
  }

  async function insertAndSend(text) {
    const el = findComposer();
    if (!el) return false;
    insertText(el, text);
    await new Promise((r) => setTimeout(r, 500));
    const btn = findSendButton();
    if (btn) { btn.click(); return true; }
    // atsarginis: Enter
    el.dispatchEvent(new KeyboardEvent("keydown", {
      key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true
    }));
    return true;
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && msg.type === "callhub-insert") {
      insertAndSend(msg.text)
        .then((ok) => sendResponse({ ok }))
        .catch(() => sendResponse({ ok: false }));
      return true; // async
    }
  });
})();
