@echo off
title CallHub
cd /d "%~dp0"
:loop
python callhub.py
if %errorlevel%==42 goto loop
pause
