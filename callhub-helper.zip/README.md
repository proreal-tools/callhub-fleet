# CallHub — click-to-call + auto-transkripcija

Paspaudus telefono numerį naršyklėje → Poco telefonas skambina ir įrašo →
įrašas per Syncthing atkeliauja į kompą → lokalus Whisper transkribuoja (LT) →
transkripcija atsiranda extension'o popup'e su „kopijuoti" mygtuku.

## Dalys

```
Chrome extension (extension/)  --HTTP-->  callhub.py (127.0.0.1:8199)  --adb-->  Poco (skambina + įrašo)
        ^                                        |
        |                                        +-- stebi recordings/  --whisper--> transkripcija
        +-------------------- /calls -------------+
```

- **callhub.py** — vietinis serveris. `/dial` (skambink per adb), `/calls` (transkripcijos), `/health`.
- **extension/** — Chrome MV3: numeriai puslapyje tampa paspaudžiami; popup rodo transkripcijas.
- **config.json** — keliai (adb, whisper venv), telefono adresas, įrašų aplankas.
- **recordings/** — čia Syncthing atkelia Poco įrašus.

## Paleidimas
1. `start.bat` (paleidžia callhub.py; langą palik atidarytą).
2. Chrome → `chrome://extensions` → „Developer mode" ON → „Load unpacked" → nurodyk `C:\Users\linas\CallHub\extension`.

## Telefono pusė (vienkartinis setup)
1. **Įrašymas:** MIUI Telefonas → Nustatymai → Skambučių įrašymas → Auto → Visi.
2. **ADB:** Nustatymai → Apie telefoną → 7× spausk „MIUI versija" (Developer options) →
   Developer options → įjunk **USB debugging** (ir „Wireless debugging" belaidžiui).
   Prijungus USB, priimk „Allow USB debugging".
3. **Belaidis adb (kad nereikėtų kabelio):** vienkart per USB paleisk
   `adb tcpip 5555`, sužinok telefono IP (WiFi nustatymuose), tada
   `config.json` → `"phone_addr": "TELEFONO_IP:5555"`.
4. **Syncthing:** įdiek telefone + kompe; susiek Poco įrašų aplanką
   (pvz. `MIUI/sound_recorder/call_rec/` arba `Recordings/call/`) su
   `C:\Users\linas\CallHub\recordings`.

## Derinimas
- Jei `am start ACTION_CALL` telefone tik atidaro dialerį (nesurenka), MIUI gali
  reikalauti kito būdo — tada pereisim prie Tasker varianto.
- Įrašų aplanko tikslų kelią rasim, kai telefonas prijungtas (`adb shell ls`).
- `transcribe_backlog: true` config'e — jei nori transkribuoti ir jau esančius įrašus.
