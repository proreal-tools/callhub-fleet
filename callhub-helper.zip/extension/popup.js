const HUB = "http://127.0.0.1:8199";
const listEl = document.getElementById("list");
const statusEl = document.getElementById("status");
const dotEl = document.getElementById("dot");
let lastCallsSig = "";   // kad neperpieštume sąrašo be reikalo (slinktis neatšoktų)
let lastDiagSig = null;  // diagnostikos juosta — perpiešiam tik kai priežastis pasikeičia
let diagBusy = false;    // aktyvi /diagnose patikra vyksta — poll'as neperpiešia (kad nenumuštų „Tikrinama…")

function esc(s) {
  return (s || "").replace(/[&<>]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));
}

function fmtTime(iso) {
  if (!iso) return "";
  try {
    const d = new Date(iso);
    return d.toLocaleString("lt-LT", { dateStyle: "short", timeStyle: "short" });
  } catch { return iso; }
}

function fmtDur(s) {
  if (s === null || s === undefined) return "";
  const m = Math.floor(s / 60), ss = String(s % 60).padStart(2, "0");
  return `⏱ ${m}:${ss}`;
}

function fmtWhen(iso) {
  if (!iso) return "";
  try {
    const d = new Date(iso);
    return "· atnaujinta " + d.toLocaleDateString("lt-LT", { day: "numeric", month: "short" });
  } catch { return ""; }
}

function fmtAgo(epoch) {
  if (!epoch) return "";
  const s = Math.max(0, Math.floor(Date.now() / 1000 - epoch));
  if (s < 60) return "prieš " + s + " s";
  if (s < 3600) return "prieš " + Math.floor(s / 60) + " min";
  if (s < 86400) return "prieš " + Math.floor(s / 3600) + " val.";
  return "prieš " + Math.floor(s / 86400) + " d.";
}

function setVersionBox(h) {
  // Versija antraštėje — visada matoma (visuose skirtukuose)
  const hdrV = document.getElementById("hdrVer");
  if (hdrV) hdrV.textContent = (h.helper_version != null) ? ("v" + h.helper_version) : "";
  // Pasiekiamumas = TIKRAS testas (ne „ar WiFi", o ar helper mato telefoną per adb)
  const reach = document.getElementById("verReach");
  if (reach) {
    const netc = (h.net_connected !== undefined) ? h.net_connected : h.phone_connected;
    if (netc) {
      const how = h.lan_present ? "per LAN (WiFi)" : (h.phone_connected ? "per adb" : "per internetą");
      reach.innerHTML = '🟢 <b style="color:#0b6e4f">Telefonas pasiekiamas</b> ' + how;
    } else {
      const ago = fmtAgo(h.last_seen_at);
      reach.innerHTML = '🔴 <b style="color:#b3261e">Nepasiekiamas</b>'
        + (ago ? ' · matytas ' + ago : '')
        + ' — atnaujinimai nekeliaus, kol nepasieks';
    }
  }
  const vh = document.getElementById("verHelper");
  if (vh) vh.textContent = (h.helper_version != null) ? ("v" + h.helper_version) : "—";
  const vhAt = document.getElementById("verHelperAt");
  if (vhAt) vhAt.textContent = fmtWhen(h.helper_updated_at);

  // Telefono savęs-pranešimas iš Firebase — matoma NET kai adb neveikia
  const repEl = document.getElementById("verReport");
  if (repEl) {
    const rep = h.phone_report;
    if (rep && rep.at) {
      const usb = rep.usb_debugging === 1 ? "USB debug ✓" : (rep.usb_debugging === 0 ? "USB debug ✗" : "USB debug ?");
      const wifi = rep.wifi_on ? (rep.wifi_ip || "WiFi ✓") : "WiFi ✗";
      repEl.innerHTML = "📱 Telefonas pranešė " + esc(fmtAgo(rep.at / 1000)) + " · " + esc(wifi) + " · " + usb + " · v" + esc(String(rep.version_code));
    } else {
      repEl.textContent = "📱 Telefonas dar nepranešė (atidaryk app'sę telefone)";
    }
  }

  const va = document.getElementById("verApk");
  if (va) va.textContent = (h.apk_version != null) ? ("v" + h.apk_version) : "—";
  const vaAt = document.getElementById("verApkAt");
  if (vaAt) {
    let note = "";
    if (h.phone_connected) {
      if (h.apk_update_blocked) note = '⚠️ reikia „Install via USB"';
      else if (h.apk_version != null && h.apk_latest != null && h.apk_latest > h.apk_version)
        note = "→ laukia v" + h.apk_latest + " (įdiegs automatiškai)";
      else if (h.apk_version != null)
        note = "naujausia ✓" + (h.apk_updated_at ? " " + fmtWhen(h.apk_updated_at) : "");
    }
    vaAt.textContent = note;
  }
}

// ---- Gyva progreso juosta ----
const stageEl = document.getElementById("stage");
let curStage = "idle";
let curProgress = null;
let displayProgress = 0;
let timerBase = null; // { elapsed, at } — laikmačiui

const STAGE_INFO = {
  dialing:      { text: "📞 Skambinama…", color: "#1565c0" },
  in_call:      { text: "📞 Pokalbis vyksta", color: "#0b6e4f" },
  waiting:      { text: "🔎 Pokalbis baigėsi — ieškoma įrašo…", color: "#6a1b9a" },
  pulling:      { text: "⬇️ Parsiunčiamas įrašas…", color: "#6a1b9a" },
  transcribing: { text: "📝 Transkribuojama…", color: "#b8860b" },
};

async function hangupCall() {
  try { await fetch(HUB + "/hangup", { method: "POST" }); } catch (e) {}
}

function renderStage() {
  const info = STAGE_INFO[curStage];
  const textEl = document.getElementById("stageText");
  const hangupBtn = document.getElementById("stageHangup");
  if (!info || !stageEl) { if (stageEl) stageEl.style.display = "none"; displayProgress = 0; return; }
  stageEl.style.display = "flex";
  stageEl.style.background = info.color;
  let txt;
  // Laikmatis skaičiuoja nuo SUJUNGIMO: telefonas praneša „in_call" tik kai prasideda įrašas
  // (jis pildosi tik po atsiliepimo), tad _call_started ≈ pašnekovas atsiliepė.
  if (curStage === "in_call" && timerBase) {
    const e = Math.floor(timerBase.elapsed + (performance.now() - timerBase.at) / 1000);
    const m = Math.floor(e / 60), ss = String(e % 60).padStart(2, "0");
    txt = "📞 Pokalbis vyksta · " + m + ":" + ss;
  } else if (curStage === "transcribing") {
    const target = (curProgress != null) ? curProgress : 0;
    displayProgress += (target - displayProgress) * 0.35;      // sklandus judėjimas link tikslo
    if (Math.abs(target - displayProgress) < 1) displayProgress = target;
    const p = Math.round(displayProgress);
    txt = p > 0 ? "📝 Transkribuojama… " + p + "%" : "📝 Transkribuojama…";
  } else {
    txt = info.text;
  }
  if (textEl) textEl.textContent = txt;
  if (hangupBtn) hangupBtn.style.display = (curStage === "dialing" || curStage === "in_call") ? "block" : "none";
}
setInterval(renderStage, 300);

const stageHangupBtn = document.getElementById("stageHangup");
if (stageHangupBtn) stageHangupBtn.addEventListener("click", hangupCall);

async function retranscribe(file) {
  try {
    await fetch(HUB + "/retranscribe", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ file })
    });
    setTimeout(refresh, 300);
  } catch {}
}

function playCall(file) {
  const player = document.getElementById("player");
  const bar = document.getElementById("playerBar");
  if (!player || !bar) return;
  if (player.getAttribute("data-file") === file && !player.paused) {
    player.pause();
    return;
  }
  player.setAttribute("data-file", file);
  player.src = HUB + "/audio?file=" + encodeURIComponent(file);
  bar.style.display = "block";
  player.play().catch(() => {});
}

// Auto-perkrauna plėtinį, kai helper atsinaujino (nauji failai jau diske)
async function checkExtReload(v) {
  if (v == null) return;
  try {
    const { extVersion } = await chrome.storage.local.get("extVersion");
    if (extVersion == null) { await chrome.storage.local.set({ extVersion: v }); return; }
    if (v > extVersion) {
      await chrome.storage.local.set({ extVersion: v, justUpdatedTo: v });   // žymė toast'ui po persikrovimo
      chrome.runtime.reload();
    }
  } catch (e) {}
}

function showUpdateToast(v) {
  const t = document.getElementById("updToast");
  if (!t) return;
  t.textContent = "✅ Atnaujinta į v" + v + " — spausk, kad paslėptum";
  t.style.display = "block";
  t.onclick = () => { t.style.display = "none"; };
  setTimeout(() => { if (t) t.style.display = "none"; }, 10000);
}

// Po persikrovimo (atnaujinimo) parodom pranešimą, kad TIKRAI atsinaujino
chrome.storage.local.get("justUpdatedTo", (d) => {
  if (d && d.justUpdatedTo != null) {
    showUpdateToast(d.justUpdatedTo);
    chrome.storage.local.remove("justUpdatedTo");
  }
});

// ---- AI: patobulinti pardavimo skriptą pagal pokalbį ----
const AI_Q = {
  chatgpt: (p) => "https://chatgpt.com/?q=" + encodeURIComponent(p),
  claude: (p) => "https://claude.ai/new?q=" + encodeURIComponent(p),
};
const AI_BASE = { chatgpt: "https://chatgpt.com/", claude: "https://claude.ai/new" };

const aiSel = document.getElementById("ai");
chrome.storage.local.get("ai", (d) => { if (d && d.ai && aiSel) aiSel.value = d.ai; });
if (aiSel) aiSel.addEventListener("change", () => chrome.storage.local.set({ ai: aiSel.value }));

const newChatBtn = document.getElementById("newchat");
if (newChatBtn) newChatBtn.addEventListener("click", newAiChat);

const openAiBtn = document.getElementById("openai");
if (openAiBtn) openAiBtn.addEventListener("click", () => {
  const provider = (aiSel && aiSel.value) || "chatgpt";
  chrome.runtime.sendMessage({ type: "aiOpen", provider }, () => aiFeedback("Atidarau AI langą…"));
});

const tabCallsBtn = document.getElementById("tabCalls");
const tabObjBtn = document.getElementById("tabObj");
const tabDevBtn = document.getElementById("tabDev");
if (tabCallsBtn) tabCallsBtn.addEventListener("click", () => setView("calls"));
if (tabObjBtn) tabObjBtn.addEventListener("click", () => setView("objections"));
if (tabDevBtn) tabDevBtn.addEventListener("click", () => setView("devices"));
document.querySelectorAll(".objcat").forEach(b =>
  b.addEventListener("click", () => renderObjections(b.dataset.cat)));

const devFindBtn = document.getElementById("devFind");
if (devFindBtn) devFindBtn.addEventListener("click", findPhone);
const retSaveBtn = document.getElementById("retSave");
if (retSaveBtn) retSaveBtn.addEventListener("click", saveRetention);
const devConnectBtn = document.getElementById("devConnect");
if (devConnectBtn) devConnectBtn.addEventListener("click", () => {
  const ipEl = document.getElementById("devIp");
  connectIp((ipEl && ipEl.value || "").trim());
});
loadObjections();

function buildPrompt(c) {
  const dur = fmtDur(c.duration_sec).replace("⏱ ", "");
  const meta = `${c.number || "?"}${dur ? ", " + dur : ""}`;
  return `Esu nekilnojamojo turto brokeris. Žemiau – mano telefoninio pokalbio su klientu transkripcija (įrašyta ir transkribuota automatiškai).

Tavo užduotis – padėti patobulinti mano pardavimo skriptą pagal šį realų pokalbį:
1. Trumpai įvertink pokalbį: kas pavyko, kur praradau kliento dėmesį ar pasitikėjimą.
2. Išvardink kliento prieštaravimus/abejones ir pasiūlyk, kaip į jas atsakyti įtaigiau.
3. Pasiūlyk konkrečias patobulintas frazes pagal struktūrą: Kabliukas (Hook) → Problema → Sprendimas → Raginimas veikti (CTA).
4. Pateik pilną patobulintą skripto versiją kitiems skambučiams.

Atsakyk lietuviškai, konkrečiai ir praktiškai.

--- POKALBIS (${meta}) ---
${c.transcript || ""}
--- PABAIGA ---`;
}

function openTab(url) {
  try { chrome.tabs.create({ url }); }
  catch (e) { window.open(url, "_blank"); }
}

function aiFeedback(text) {
  const el = document.getElementById("aimsg");
  if (!el) return;
  el.textContent = text;
  clearTimeout(aiFeedback._t);
  aiFeedback._t = setTimeout(() => { el.textContent = ""; }, 5000);
}

async function improveScript(c, forceNew) {
  const provider = (aiSel && aiSel.value) || "chatgpt";
  const prompt = buildPrompt(c);
  try { await navigator.clipboard.writeText(prompt); } catch {}
  aiFeedback("⏳ Atidarau AI…");
  chrome.runtime.sendMessage({ type: "aiImprove", prompt, provider, forceNew: !!forceNew }, (res) => {
    if (chrome.runtime.lastError || !res || !res.ok) {
      openTab(AI_BASE[provider]);
      aiFeedback("Įklijuok Ctrl+V į AI langą");
    } else if (res.injected) {
      aiFeedback((res.reused ? "✓ Įrašyta į tą patį AI chatą" : "✓ Naujas AI chatas atidarytas") + " (fone) — spausk 🔗");
    } else {
      aiFeedback("AI atidarytas fone — spausk 🔗, tada Ctrl+V");
    }
  });
}

function newAiChat() {
  chrome.runtime.sendMessage({ type: "aiNewChat" }, () => {
    aiFeedback("Kitas skambutis atsidarys naujame AI chate");
  });
}

// ---- Atsikalbinėjimai (savininkų prieštaravimai + atsakymai) ----
const DEFAULT_OBJECTIONS = {
  nuoma: [
    { q: `Aš pats išnuomosiu, brokerio nereikia.`,
      a: `Suprantu — daug savininkų taip pradeda. Tik dažnai patiems tenka gaišti laiką skambučiams, apžiūroms ir tikrinti nuomininkų mokumą. Aš atsijoju netinkamus, atvedu tik mokius ir sutvarkau sutartį — jums lieka pasirašyti. Ar galiu parodyti, ką konkrečiai padaryčiau jūsų butui?` },
    { q: `Komisinis per didelis.`,
      a: `Komisinį atperka greitis ir tinkamas nuomininkas. Blogas nuomininkas kainuoja kelis mėnesius nuostolių ir nervų. Aš pasirūpinu, kad butas neprastovėtų ir mokėtų laiku. Kas svarbiau — sutaupyti dabar ar išvengti brangaus nuomininko vėliau?` },
    { q: `Jau turiu kelis brokerius.`,
      a: `Puiku, vadinasi vertinate pagalbą. Skirtumas — aš dirbu tik su keliais objektais ir įsigilinu. Ar galiu pateikti savo pasiūlymą, kad turėtumėte su kuo palyginti?` },
    { q: `Neskubu, tik pažiūriu kainą.`,
      a: `Tvarka — rinka keičiasi greitai. Galiu nemokamai įvertinti realią jūsų buto nuomos kainą pagal šviežius sandorius, kad žinotumėte tikslų skaičių. Kada patogiau — šiandien ar rytoj?` },
    { q: `Iš kur turite mano numerį?`,
      a: `Radau jūsų skelbimą — matau, kad nuomojate patys. Būtent todėl ir skambinu: galiu padėti išnuomoti greičiau ir saugiau. Skiriate minutę?` },
    { q: `Palikite numerį, perskambinsiu.`,
      a: `Žinoma, paliksiu. Kad neatidėtume — gal iškart sutarkim trumpą 10 min pokalbį jums patogiu laiku? Kada geriau — rytoj iki pietų ar po pietų?` },
  ],
  pardavimas: [
    { q: `Parduosiu pats, be brokerio.`,
      a: `Suprantu. Jei norite maksimalios kainos ir be klaidų sutartyse — aš atsakau už rezultatą. Ar galiu parodyti, kiek panašūs būstai realiai pardavė per pastarąjį mėnesį?` },
    { q: `Komisinis per didelis.`,
      a: `Geras brokeris ne kainuoja, o uždirba — dažnai išderi aukštesnę kainą, nei savininkas pats. Skirtumas neretai viršija komisinį. Ar svarbiausia jums galutinė suma į rankas?` },
    { q: `Jau dirbu su kitu brokeriu.`,
      a: `Supratau. Ar jaučiate rezultatą — objektas juda? Jei ne, galiu duoti antrą nuomonę dėl kainos ir strategijos, nemokamai.` },
    { q: `Duokite pirkėją, tada kalbėsim.`,
      a: `Būtent taip ir dirbu. Bet kad atvesčiau tinkamą pirkėją, reikia teisingos kainos ir gerų nuotraukų. Leiskit 15 min įvertinti — ir turėsiu ką pasiūlyti realiems pirkėjams.` },
    { q: `Jūsų kaina per žema, tik norit greičiau parduoti.`,
      a: `Suprantu baimę. Remiuosi ne nuojauta, o realiais sandoriais — parodysiu skaičius. Jei jūsų kaina reali, palaikysiu ją; jei per aukšta, pasakysiu sąžiningai, kad objektas neprastovėtų.` },
    { q: `Neskubu parduoti.`,
      a: `Tvarka. Tik rinkoje laikas = pinigai: ilgai kabantis skelbimas atrodo įtartinas ir numuša kainą. Paruošiu taip, kad parduotume greitai ir gera kaina, kai nuspręsite. Įvertinam dabar?` },
  ],
};

let currentCat = "nuoma";
let objData = null;

function saveObjections() {
  chrome.storage.local.set({ objections: objData });
}
let _saveT;
function saveSoon() { clearTimeout(_saveT); _saveT = setTimeout(saveObjections, 400); }

function loadObjections(cb) {
  chrome.storage.local.get("objections", (d) => {
    objData = (d && d.objections) ? d.objections : JSON.parse(JSON.stringify(DEFAULT_OBJECTIONS));
    if (!objData.nuoma) objData.nuoma = [];
    if (!objData.pardavimas) objData.pardavimas = [];
    if (cb) cb();
  });
}

function autoGrow(ta) { ta.style.height = "auto"; ta.style.height = (ta.scrollHeight + 2) + "px"; }

function renderObjections(cat) {
  currentCat = cat;
  if (!objData) { loadObjections(() => renderObjections(cat)); return; }
  document.querySelectorAll(".objcat").forEach(b => b.classList.toggle("active", b.dataset.cat === cat));
  const box = document.getElementById("objlist");
  box.innerHTML = "";
  const items = objData[cat] || (objData[cat] = []);

  items.forEach((o, i) => {
    const d = document.createElement("div");
    d.className = "obj";

    const qta = document.createElement("textarea");
    qta.className = "q-edit"; qta.value = o.q; qta.placeholder = "Prieštaravimas…";
    qta.addEventListener("input", () => { o.q = qta.value; autoGrow(qta); saveSoon(); });

    const ata = document.createElement("textarea");
    ata.className = "a-edit"; ata.value = o.a; ata.placeholder = "Atsakymas…";
    ata.addEventListener("input", () => { o.a = ata.value; autoGrow(ata); saveSoon(); });

    const btns = document.createElement("div"); btns.className = "btns";
    const copy = document.createElement("button"); copy.textContent = "Kopijuoti atsakymą";
    copy.addEventListener("click", () => navigator.clipboard.writeText(o.a));
    const del = document.createElement("button"); del.textContent = "🗑"; del.title = "Trinti";
    del.addEventListener("click", () => { items.splice(i, 1); saveObjections(); renderObjections(cat); });
    btns.appendChild(copy); btns.appendChild(del);

    d.appendChild(qta); d.appendChild(ata); d.appendChild(btns);
    box.appendChild(d);
    autoGrow(qta); autoGrow(ata);
  });

  const add = document.createElement("button");
  add.className = "add-obj"; add.textContent = "➕ Pridėti prieštaravimą";
  add.addEventListener("click", () => { items.push({ q: "", a: "" }); saveObjections(); renderObjections(cat); });
  box.appendChild(add);

  const reset = document.createElement("button");
  reset.className = "reset-obj"; reset.textContent = "↺ Atstatyti numatytus";
  let armed = false;
  reset.addEventListener("click", () => {
    if (!armed) { reset.textContent = "Tikrai? Spausk dar kartą"; armed = true; setTimeout(() => { reset.textContent = "↺ Atstatyti numatytus"; armed = false; }, 3000); return; }
    objData[cat] = JSON.parse(JSON.stringify(DEFAULT_OBJECTIONS[cat] || []));
    saveObjections(); renderObjections(cat);
  });
  box.appendChild(reset);
}

// ---- Telefono (adb įrenginio) pasirinkimas ----
function devMsg(text) {
  const el = document.getElementById("devMsg");
  if (el) el.textContent = text || "";
}

function renderDevices(data) {
  const box = document.getElementById("devlist");
  const active = document.getElementById("devActive");
  if (active) active.textContent = data.selected || "— nepasirinkta —";
  if (!box) return;
  box.innerHTML = "";
  const devs = data.devices || [];
  if (!devs.length) {
    box.innerHTML = '<div class="empty">Nerasta telefonų.<br>Prijunk USB ir spausk „Ieškoti", arba įvesk IP žemiau.</div>';
    return;
  }
  devs.forEach(d => {
    const row = document.createElement("div");
    row.className = "dev" + (d.selected ? " sel" : "");
    const label = document.createElement("div");
    const tag = (d.wifi ? "WiFi" : "USB") + (d.online ? "" : " · offline");
    label.innerHTML = `<b>${esc(d.model)}</b><br><span class="dev-id">${esc(d.id)} · ${tag}</span>`;
    row.appendChild(label);
    const btns = document.createElement("div");
    const pick = document.createElement("button");
    pick.textContent = d.selected ? "✓ Pasirinktas" : "Pasirinkti";
    pick.addEventListener("click", () => selectDevice(d.id));
    btns.appendChild(pick);
    if (!d.wifi && d.online) {
      const w = document.createElement("button");
      w.textContent = "📶 Belaidis";
      w.title = "Paversti belaidžiu (be kabelio)";
      w.addEventListener("click", () => makeWireless(d.id));
      btns.appendChild(w);
    }
    row.appendChild(btns);
    box.appendChild(row);
  });
}

async function loadDevices() {
  try {
    const data = await (await fetch(HUB + "/devices")).json();
    renderDevices(data);
  } catch {
    const box = document.getElementById("devlist");
    if (box) box.innerHTML = '<div class="empty">Serveris nepasiekiamas (paleisk start.bat).</div>';
  }
  loadRetention();
}

async function loadRetention() {
  const el = document.getElementById("retDays");
  if (!el || document.activeElement === el) return;   // neperrašom kol vartotojas rašo
  try {
    const h = await (await fetch(HUB + "/health")).json();
    if (h.retention_days != null) el.value = h.retention_days;
  } catch {}
}

async function saveRetention() {
  const el = document.getElementById("retDays");
  const rmsg = document.getElementById("retMsg");
  const days = parseInt(el && el.value, 10);
  try {
    const res = await (await fetch(HUB + "/retention", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ days: isNaN(days) ? 30 : days })
    })).json();
    if (rmsg) { rmsg.textContent = "✓ Išsaugota: " + res.retention_days + " d."; setTimeout(() => rmsg.textContent = "", 4000); }
  } catch { if (rmsg) rmsg.textContent = "⚠️ Klaida"; }
}

async function selectDevice(id) {
  devMsg("⏳ Pasirenku…");
  try {
    await fetch(HUB + "/select", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id }) });
    devMsg("✓ Pasirinkta: " + id);
  } catch { devMsg("⚠️ Klaida"); }
  loadDevices();
}

async function makeWireless(serial) {
  devMsg("⏳ Įjungiu belaidį (kol kas nekišk/neištrauk kabelio)…");
  try {
    const res = await (await fetch(HUB + "/wireless", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ serial }) })).json();
    devMsg(res.ok ? ("✓ Belaidis: " + res.device + " — dabar gali ištraukti kabelį") : ("⚠️ " + (res.error || "nepavyko")));
  } catch { devMsg("⚠️ Klaida"); }
  loadDevices();
}

async function connectIp(ip) {
  if (!ip) return;
  devMsg("⏳ Jungiuosi…");
  try {
    const res = await (await fetch(HUB + "/connect", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ip }) })).json();
    devMsg(res.ok ? ("✓ Prisijungta: " + res.device) : "⚠️ Nepavyko — ar telefonas tame pačiame WiFi ir belaidis adb įjungtas?");
  } catch { devMsg("⚠️ Klaida"); }
  loadDevices();
}

async function findPhone() {
  devMsg("⏳ Ieškau (USB + tinklas)…");
  await loadDevices();                          // 1) ką adb jau mato (USB / prisijungę)
  try {
    const h = await (await fetch(HUB + "/health")).json();
    if (h.phone_connected) { devMsg("✓ Telefonas prisijungęs"); loadDevices(); return; }
  } catch {}
  devMsg("⏳ Skenuoju tinklą (~10 s)…");         // 2) jei ne — skenuoja WiFi
  try {
    const res = await (await fetch(HUB + "/rescan", { method: "POST" })).json();
    devMsg(res.ok ? ("✓ Rastas: " + res.device)
                  : "⚠️ Nerasta. Jei perkrovei telefoną — prijunk USB ir spausk 📶 Belaidis.");
  } catch { devMsg("⚠️ Klaida"); }
  loadDevices();
}

function setView(view) {
  const calls = view === "calls";
  const obj = view === "objections";
  const dev = view === "devices";
  document.getElementById("toolbar").style.display = calls ? "flex" : "none";
  document.getElementById("list").style.display = calls ? "block" : "none";
  document.getElementById("objections").style.display = obj ? "flex" : "none";
  document.getElementById("devices").style.display = dev ? "flex" : "none";
  document.getElementById("tabCalls").classList.toggle("active", calls);
  document.getElementById("tabObj").classList.toggle("active", obj);
  document.getElementById("tabDev").classList.toggle("active", dev);
  if (obj) renderObjections(currentCat);
  if (dev) loadDevices();
}

const diagEl = document.getElementById("diag");

function renderDiag(d) {
  const steps = (d.steps || []).map(s => `<div class="dstep">${esc(s)}</div>`).join("");
  diagEl.innerHTML =
    `<div class="dtitle">🔴 ${esc(d.title || "Telefonas neprijungtas")}</div>` +
    (d.detail ? `<div class="ddetail">${esc(d.detail)}</div>` : "") +
    steps +
    `<button id="diagBtn">🔄 Patikrinti / prijungti dabar</button>`;
  diagEl.style.display = "block";
  const btn = document.getElementById("diagBtn");
  btn.addEventListener("click", async () => {
    btn.disabled = true;
    diagBusy = true;
    btn.textContent = "⏳ Tikrinama (gali užtrukti ~10 s)…";
    try {
      const r = await (await fetch(HUB + "/diagnose", { method: "POST" })).json();
      if (r && r.status === "ok") {
        diagEl.style.display = "none";
        lastDiagSig = null;
      } else if (r) {
        lastDiagSig = JSON.stringify(r);
        diagBusy = false;   // prieš perpiešiant, kad naujas mygtukas nebūtų „busy"
        renderDiag(r);
      }
    } catch {
      btn.disabled = false;
      btn.textContent = "🔄 Patikrinti / prijungti dabar";
    } finally {
      diagBusy = false;
    }
  });
}

async function refresh() {
  let health = null;
  try {
    health = await (await fetch(HUB + "/health")).json();
    checkExtReload(health.helper_version);
    if (health.blocked) {
      dotEl.style.background = "#e74c3c";
      statusEl.lastChild.textContent = " 🚫 IŠJUNGTA";
      curStage = "idle"; renderStage();
      listEl.innerHTML = `<div class="empty" style="color:#b3261e;font-weight:600;padding:30px 16px;">🚫 Sistema išjungta<br><br>${esc(health.block_reason || "")}<br><br>Kreipkis į administratorių.</div>`;
      return;
    }
    const conn = (health.net_connected !== undefined) ? health.net_connected : health.phone_connected;
    const disabled = health.phone_enabled === false;
    dotEl.style.background = !conn ? "#e67e22" : (disabled ? "#e74c3c" : "#2ecc71");
    let phone;
    if (!conn) phone = "📵 telefonas atjungtas · ";
    else if (disabled) phone = "📵 CallHub IŠJUNGTAS telefone · ";
    else phone = "📱 " + ((health.phone_report && health.phone_report.model) || health.device_model || "telefonas") + " · ";
    statusEl.lastChild.textContent = ` ${phone}${health.calls} įrašų`;
    curStage = health.stage || "idle";
    curProgress = (health.progress === null || health.progress === undefined) ? null : health.progress;
    timerBase = (curStage === "in_call") ? { elapsed: health.elapsed || 0, at: performance.now() } : null;
    renderStage();
    // Savidiagnostika: kai telefonas neprijungtas — parodom priežastį + žingsnius (perpiešiam tik kai keičiasi)
    if (!health.phone_connected && health.diagnosis) {
      const dsig = JSON.stringify(health.diagnosis);
      if (!diagBusy && dsig !== lastDiagSig) { lastDiagSig = dsig; renderDiag(health.diagnosis); }
    } else {
      lastDiagSig = null;
      if (diagEl) diagEl.style.display = "none";
    }
    setVersionBox(health);   // „Versijos" blokas (Telefonas skirtuke)
  } catch {
    dotEl.style.background = "#e74c3c";
    statusEl.lastChild.textContent = " serveris neveikia — paleisk start.bat";
    listEl.innerHTML = `<div class="empty">CallHub serveris nepasiekiamas.<br>Paleisk <b>C:\\Users\\linas\\CallHub\\start.bat</b></div>`;
    curStage = "idle"; renderStage();
    return;
  }

  let calls = [];
  try { calls = await (await fetch(HUB + "/calls")).json(); } catch {}

  const sig = JSON.stringify(calls.map(c => [c.file, c.status, c.transcript, c.number, c.has_audio, c.duration_sec]));
  if (sig === lastCallsSig) return;   // niekas nepasikeitė — neperpiešiam (slinktis lieka vietoj)
  lastCallsSig = sig;

  if (!calls.length) {
    listEl.innerHTML = `<div class="empty">Kol kas nėra įrašų.<br>Paskambink — po pokalbio transkripcija atsiras čia.</div>`;
    return;
  }

  listEl.innerHTML = "";
  for (const c of calls) {
    const div = document.createElement("div");
    div.className = "call";
    const dur = fmtDur(c.duration_sec);
    div.innerHTML = `
      <div class="row">
        <span class="num">${esc(c.number || "?")}</span>
        <span class="time">${dur ? dur + " · " : ""}${esc(fmtTime(c.transcribed_at))}</span>
      </div>
      <div class="txt">${c.status === "transcribing"
        ? "<span style='color:#c77;font-style:italic'>⏳ Transkribuojama…</span>"
        : esc(c.transcript || "")}</div>
      <button class="ai">✨ Tobulinti skriptą su AI</button>
      <div class="btns">
        ${c.has_audio ? '<button class="play">▶ Klausyti</button>' : ''}
        <button class="copy">Kopijuoti</button>
        <button class="copyboth">Numeris + tekstas</button>
        <button class="retry" title="Transkribuoti iš naujo">🔄</button>
      </div>`;
    div.querySelector(".ai").addEventListener("click", () => improveScript(c));
    div.querySelector(".copy").addEventListener("click", () => {
      navigator.clipboard.writeText(c.transcript || "");
    });
    div.querySelector(".copyboth").addEventListener("click", () => {
      navigator.clipboard.writeText(`${c.number || "?"} (${fmtTime(c.transcribed_at)})\n${c.transcript || ""}`);
    });
    div.querySelector(".retry").addEventListener("click", () => retranscribe(c.file));
    const playBtn = div.querySelector(".play");
    if (playBtn) playBtn.addEventListener("click", () => playCall(c.file));
    listEl.appendChild(div);
  }
}

refresh();
setInterval(refresh, 2000);
