"""CallHub — vietinis tarpininkas tarp Chrome extension'o ir Poco telefono.

Ką daro:
  1) POST /dial  {number}  -> per adb liepia telefonui surinkti numerį (ACTION_CALL).
  2) Stebi recordings/ aplanką (į jį Syncthing atkelia MIUI įrašus). Naują įrašą
     automatiškai transkribuoja lokaliu faster-whisper (LT) ir įsimena tekstą.
  3) GET /calls -> grąžina paskutinius skambučius su transkripcijomis (extension'ui).
  4) GET /health -> adb būsena.

Tik standartinė biblioteka. Whisper ir adb kviečiami kaip išoriniai procesai.
"""

from __future__ import annotations

import json
import os
import re
import socket
import subprocess
import threading
import time
import urllib.request
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs, unquote

HELPER_VERSION = 6             # didinti KIEKVIENAM atnaujinimui (kitaip nepasiūlys naujesnės)
DIALER_PKG = "lt.callhub.dialer"   # telefono app'sės paketas (APK auto-atnaujinimui)

BASE = Path(__file__).resolve().parent
CONFIG = json.loads((BASE / "config.json").read_text(encoding="utf-8"))
DATA_FILE = BASE / "calls.json"
DEVICE_FILE = BASE / "selected_device.json"   # pasirinktas telefonas (išlieka po perkrovimo)
COMPUTER_NAME = CONFIG.get("computer_name") or socket.gethostname()   # rodomas telefone

# ---- Būsena ----
_lock = threading.Lock()
_calls: list[dict] = []        # {id, number, dialed_at, file, transcribed_at, transcript, status}
_pending: list[dict] = []      # neseniai surinkti numeriai, laukiantys įrašo: {number, ts}
_in_call = False               # ar šiuo metu vyksta skambutis (atnaujina adb_pull_loop)
_call_started = None           # skambučio pradžios laikas (laikmačiui)
_call_ended_at = None          # kada baigėsi (laukimo/paieškos fazei)
_awaiting = False              # įrašas parsisiųstas, laukia transkripcijos
_transcribe_progress = 0       # 0–100 dabartinės transkripcijos progresas
_call_phase = "idle"           # idle | dialing | active (iš dumpsys telecom)
_selected_device = CONFIG.get("phone_addr", "")   # aktyvus adb įrenginys (serial arba IP:port)
_known_serial = ""             # telefono ro.serialno (tapatybė — atpažinti po IP pasikeitimo)
_known_model = ""              # telefono modelis (atsarginė tapatybė)
_scanning = False              # ar šiuo metu skenuojam tinklą
_phone_enabled = None          # ar telefone CallHub įjungtas (None = nežinoma)
_blocked = False               # ar administratorius išjungė šį brokerį (fleet.json)
_block_reason = ""             # kodėl blokuota (rodoma vartotojui)
_last_fleet_ok = None          # kada paskutinį kartą sėkmingai patikrinta (grace periodui)
_apk_installed_ver = None      # telefone įdiegtos Dialer app'sės versionCode
_apk_latest_ver = None         # naujausia APK versija fleet.json'e
_apk_update_blocked = False    # ar adb install blokuotas (reikia „Install via USB")
_apk_msg = ""                  # žinutė vartotojui apie telefono APK atnaujinimą
_apk_last_tried = 0            # paskutinė versija, kurią bandėm įdiegti (kad nespam'intų)
_helper_updated_at = None      # kada helper'is paskutinį kartą pasikeitė (self-update)
_apk_updated_at = None         # kada telefono APK paskutinį kartą tyliai įdiegta


def load_calls() -> None:
    global _calls
    if DATA_FILE.exists():
        try:
            _calls = json.loads(DATA_FILE.read_text(encoding="utf-8"))
        except Exception:
            _calls = []


def save_calls() -> None:
    tmp = DATA_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(_calls, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(DATA_FILE)


VERSION_STATE_FILE = BASE / "version_state.json"


def _now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _read_version_state() -> dict:
    if VERSION_STATE_FILE.exists():
        try:
            return json.loads(VERSION_STATE_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}


def _save_version_state(st: dict) -> None:
    try:
        VERSION_STATE_FILE.write_text(json.dumps(st, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


def load_version_state() -> None:
    """Versijų laiko žymės. Jei helper versija pasikeitė (self-update) — įrašo 'dabar'."""
    global _helper_updated_at, _apk_updated_at
    st = _read_version_state()
    _apk_updated_at = st.get("apk_updated_at")
    if st.get("helper_version") != HELPER_VERSION:
        _helper_updated_at = _now_iso()
        st["helper_version"] = HELPER_VERSION
        st["helper_updated_at"] = _helper_updated_at
        _save_version_state(st)
    else:
        _helper_updated_at = st.get("helper_updated_at")


def mark_apk_updated() -> None:
    global _apk_updated_at
    _apk_updated_at = _now_iso()
    st = _read_version_state()
    st["apk_updated_at"] = _apk_updated_at
    _save_version_state(st)


# ---- Numerio normalizavimas (LT + tarptautinis) ----
def normalize_number(raw: str) -> str | None:
    s = re.sub(r"[^\d+]", "", raw or "")
    if s.startswith("00"):
        s = "+" + s[2:]
    digits = re.sub(r"\D", "", s)
    if s.startswith("+"):
        return s if 8 <= len(digits) <= 15 else None
    if len(digits) == 9 and digits.startswith("8"):     # 8 6xx xxxxx -> +3706xxxxxxx
        return "+370" + digits[1:]
    if len(digits) == 11 and digits.startswith("370"):
        return "+" + digits
    return None


def extract_number_from_name(name: str) -> str | None:
    """MIUI failo formatas: '<numeris>(<numeris/vardas>)_<laikas>.mp3'.
    Imam pirmą seką iki '(' arba '_' (skliaustų neįtraukiam, kad nesuliptų du numeriai)."""
    head = re.split(r"[(_]", name, maxsplit=1)[0]
    m = re.search(r"\+?\d[\d\s.\-]{5,}\d", head)
    if m:
        return normalize_number(m.group(0))
    return None


# ---- adb ----
def load_selected_device() -> None:
    global _selected_device, _known_serial, _known_model
    if DEVICE_FILE.exists():
        try:
            d = json.loads(DEVICE_FILE.read_text(encoding="utf-8"))
            _selected_device = d.get("device", "")
            _known_serial = d.get("serial", "")
            _known_model = d.get("model", "")
        except Exception:
            pass


def save_device_file() -> None:
    try:
        DEVICE_FILE.write_text(json.dumps(
            {"device": _selected_device, "serial": _known_serial, "model": _known_model}),
            encoding="utf-8")
    except Exception:
        pass


def set_selected_device(dev: str) -> None:
    global _selected_device
    _selected_device = dev or ""
    save_device_file()


def capture_identity(addr: str) -> None:
    """Įsimena telefono ro.serialno + modelį (kad atpažintume jį po IP pasikeitimo)."""
    global _known_serial, _known_model
    try:
        adb = CONFIG["adb_path"]
        serial = subprocess.run([adb, "-s", addr, "shell", "getprop", "ro.serialno"],
                                capture_output=True, text=True, timeout=10).stdout.strip()
        model = subprocess.run([adb, "-s", addr, "shell", "getprop", "ro.product.model"],
                               capture_output=True, text=True, timeout=10).stdout.strip()
        if serial:
            _known_serial = serial
        if model:
            _known_model = model.replace("_", " ")
        save_device_file()
    except Exception:
        pass


def is_wifi_id(dev: str) -> bool:
    return ":" in (dev or "")


def adb_base() -> list[str]:
    base = [CONFIG["adb_path"]]
    if _selected_device:
        base += ["-s", _selected_device]
    return base


def adb_connect() -> None:
    if is_wifi_id(_selected_device):
        try:
            subprocess.run([CONFIG["adb_path"], "connect", _selected_device],
                           capture_output=True, text=True, timeout=15)
        except Exception:
            pass


def adb_reconnect() -> None:
    """Priverstinis persijungimas — jei WiFi ryšys nukrito (telefonas užmigo ir pan.)."""
    if is_wifi_id(_selected_device):
        try:
            subprocess.run([CONFIG["adb_path"], "disconnect", _selected_device],
                           capture_output=True, text=True, timeout=10)
        except Exception:
            pass
        adb_connect()


def adb_devices() -> str:
    try:
        r = subprocess.run([CONFIG["adb_path"], "devices"],
                           capture_output=True, text=True, timeout=15)
        return (r.stdout or r.stderr or "").strip()
    except Exception as e:
        return f"adb error: {e}"


def list_devices() -> list:
    """Prijungti adb įrenginiai: [{id, model, wifi, online, selected}]."""
    devices = []
    try:
        r = subprocess.run([CONFIG["adb_path"], "devices", "-l"],
                           capture_output=True, text=True, timeout=15)
    except Exception:
        return devices
    for line in (r.stdout or "").splitlines():
        line = line.strip()
        if not line or line.startswith("List of devices"):
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        dev_id, state = parts[0], parts[1]
        mm = re.search(r"model:(\S+)", line)
        model = mm.group(1).replace("_", " ") if mm else dev_id
        devices.append({
            "id": dev_id, "model": model,
            "wifi": is_wifi_id(dev_id),
            "online": state == "device",
            "state": state,   # device | unauthorized | offline (diagnostikai)
            "selected": dev_id == _selected_device,
        })
    return devices


def phone_connected() -> bool:
    for d in list_devices():
        if d["online"] and (not _selected_device or d["id"] == _selected_device):
            return True
    return False


def make_wireless(serial: str) -> dict:
    """USB įrenginį paverčia belaidžiu: gauna telefono WiFi IP, adb tcpip 5555, connect."""
    adb = CONFIG["adb_path"]
    try:
        r = subprocess.run([adb, "-s", serial, "shell", "ip", "-f", "inet", "addr", "show", "wlan0"],
                           capture_output=True, text=True, timeout=15)
        m = re.search(r"inet (\d+\.\d+\.\d+\.\d+)", r.stdout or "")
        if not m:
            return {"ok": False, "error": "nerastas telefono WiFi IP (ar telefonas WiFi tinkle?)"}
        ip = m.group(1)
        subprocess.run([adb, "-s", serial, "tcpip", "5555"], capture_output=True, text=True, timeout=15)
        time.sleep(2)
        addr = f"{ip}:5555"
        subprocess.run([adb, "connect", addr], capture_output=True, text=True, timeout=15)
        set_selected_device(addr)
        capture_identity(addr)
        return {"ok": True, "device": addr, "ip": ip}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def connect_ip(ip: str) -> dict:
    ip = (ip or "").strip()
    if not ip:
        return {"ok": False, "error": "nenurodytas IP"}
    if ":" not in ip:
        ip += ":5555"
    try:
        r = subprocess.run([CONFIG["adb_path"], "connect", ip],
                           capture_output=True, text=True, timeout=15)
        out = (r.stdout or "") + (r.stderr or "")
        ok = "connected" in out.lower()
        if ok:
            set_selected_device(ip)
            capture_identity(ip)
        return {"ok": ok, "device": ip, "adb": out.strip()}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def local_subnets() -> list:
    """Visų kompo tinklo sąsajų /24 potinkliai (kad rastume telefoną net su VPN)."""
    subnets = []

    def add(ip):
        if ip and not ip.startswith(("169.254", "127.")):
            sn = ".".join(ip.split(".")[:3])
            if sn not in subnets:
                subnets.append(sn)

    try:  # numatytojo maršruto IP
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        add(s.getsockname()[0])
        s.close()
    except Exception:
        pass
    try:  # visos sąsajos per ipconfig (kad pamatytume ir WiFi, ir VPN)
        out = subprocess.run(["ipconfig"], capture_output=True, text=True, timeout=10).stdout
        for m in re.finditer(r"IPv4[^:]*:\s*(\d+\.\d+\.\d+\.\d+)", out):
            add(m.group(1))
    except Exception:
        pass
    # LAN potinklius (192.168.x) skenuojam pirma, VPN (10.x) — paskui
    subnets.sort(key=lambda sn: (0 if sn.startswith("192.168") else 1 if sn.startswith("172.") else 2))
    return subnets


def scan_5555(subnet: str) -> list:
    from concurrent.futures import ThreadPoolExecutor
    found = []

    def check(i):
        ip = f"{subnet}.{i}"
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(0.4)
        try:
            if s.connect_ex((ip, 5555)) == 0:
                found.append(ip)
        except Exception:
            pass
        finally:
            s.close()

    with ThreadPoolExecutor(max_workers=64) as ex:
        list(ex.map(check, range(1, 255)))
    return found


def scan_and_reconnect() -> dict:
    """Prasiskenuoja WiFi, randa telefoną (5555 + ta pati tapatybė) ir prisijungia."""
    global _scanning
    if _scanning:
        return {"ok": False, "error": "jau skenuojam"}
    _scanning = True
    try:
        adb = CONFIG["adb_path"]
        subnets = local_subnets()
        if not subnets:
            return {"ok": False, "error": "nepavyko nustatyti tinklo"}
        candidates = []
        for sn in subnets:
            candidates += scan_5555(sn)
        for ip in candidates:
            addr = f"{ip}:5555"
            subprocess.run([adb, "connect", addr], capture_output=True, text=True, timeout=8)
            serial = subprocess.run([adb, "-s", addr, "shell", "getprop", "ro.serialno"],
                                    capture_output=True, text=True, timeout=8).stdout.strip()
            model = subprocess.run([adb, "-s", addr, "shell", "getprop", "ro.product.model"],
                                   capture_output=True, text=True, timeout=8).stdout.strip().replace("_", " ")
            match = ((_known_serial and serial == _known_serial)
                     or (_known_model and model == _known_model)
                     or (not _known_serial and not _known_model and serial))
            if match:
                set_selected_device(addr)
                capture_identity(addr)
                print(f"[callhub] telefonas rastas tinkle: {addr} ({model})")
                return {"ok": True, "device": addr, "model": model}
            subprocess.run([adb, "disconnect", addr], capture_output=True, timeout=5)
        return {"ok": False, "error": "telefonas tinkle nerastas (tas pats WiFi? belaidis adb aktyvus?)"}
    finally:
        _scanning = False


def build_diagnosis(devs: list) -> dict:
    """Iš dabartinės adb + tinklo būsenos suformuoja ŽMOGIŠKĄ priežastį + žingsnius.
    Grąžina: {status: ok|problem, cause, title, steps:[...], detail?}."""
    sel_online = any(d["online"] and (not _selected_device or d["id"] == _selected_device) for d in devs)
    if sel_online:
        return {"status": "ok", "cause": "connected", "title": "Telefonas prijungtas", "steps": []}

    states = [d.get("state") for d in devs]
    if "unauthorized" in states:
        return {"status": "problem", "cause": "unauthorized",
                "title": "Telefonas neautorizuotas",
                "steps": [
                    "Telefone paspausk 'Leisti USB derinimą' (pažymėk 'Visada iš šio kompo').",
                    "Jei langelis nepasirodo — prijunk USB kabelį vieną kartą ir patvirtink."]}
    if "offline" in states:
        return {"status": "problem", "cause": "offline",
                "title": "Ryšys pakibęs",
                "steps": [
                    "Telefonas trumpam prarado ryšį (užmigo arba WiFi mikčioja).",
                    "Pažadink telefoną (įjunk ekraną) ir palauk ~10 sek.",
                    "Jei neatsistato — spausk 'Patikrinti dabar'."]}

    subnets = local_subnets()
    lan = [s for s in subnets if s.startswith("192.168")] or subnets   # žinutėje LAN, ne VPN (10.x)
    nets = ", ".join(f"{s}.x" for s in lan[:3]) or "?"
    return {"status": "problem", "cause": "not_on_network",
            "title": "Telefonas nepasiekiamas tinkle",
            "detail": f"Kompas tinkluose: {nets}. Telefono ({_known_model or 'Poco'}) nerandu.",
            "steps": [
                f"1. Telefono WiFi turi būti TAS PATS tinklas kaip kompo (vienas iš: {nets}) — ne mobilūs duomenys, ne 'guest'.",
                "2. Jei WiFi tas pats, o vis tiek neranda — telefonas greičiausiai persikrovė (Android 10 po perkrovimo išjungia belaidį adb).",
                "   -> Prijunk USB kabelį 1 kartą, patvirtink 'Leisti USB derinimą' telefone — ir belaidis vėl įsijungs (be laido po to)."]}


def diagnose_active() -> dict:
    """Aktyvi patikra: pabando prisijungti (senas IP + tinklo skenavimas), tada paaiškina."""
    if not _scanning and _selected_device:
        adb_connect()
        if not phone_connected():
            scan_and_reconnect()
    return build_diagnosis(list_devices())


def connection_loop() -> None:
    """Savaime prisijungia: jei telefonas dingo (pvz. WiFi keitimas) — bando seną IP, tada skenuoja."""
    while True:
        try:
            if _selected_device and not _scanning and not phone_connected():
                adb_connect()                     # greitas bandymas su paskutiniu IP
                if not phone_connected():
                    scan_and_reconnect()          # pilnas tinklo skenavimas
        except Exception:
            pass
        time.sleep(25)


def is_call_active() -> bool:
    """True, jei vyksta skambutis (mCallState != 0). Kad netrauktume nebaigto įrašo."""
    try:
        r = subprocess.run(adb_base() + ["shell", "dumpsys", "telephony.registry"],
                           capture_output=True, text=True, timeout=15)
        m = re.search(r"mCallState=(\d+)", r.stdout or "")
        return bool(m) and m.group(1) != "0"
    except Exception:
        return False


def call_phase() -> str:
    """Tiksli skambučio fazė iš dumpsys telecom: 'idle' | 'dialing' | 'active'.
    Paskutinis SET_ įvykis dump'e atspindi dabartinę būseną."""
    try:
        r = subprocess.run(adb_base() + ["shell", "dumpsys", "telecom"],
                           capture_output=True, text=True, timeout=15)
        out = r.stdout or ""
    except Exception:
        return "unknown"
    events = re.findall(r"SET_(DIALING|ACTIVE|DISCONNECTED)", out)
    if not events:
        return "idle"
    last = events[-1]
    if last == "ACTIVE":
        return "active"
    if last == "DIALING":
        return "dialing"
    return "idle"   # DISCONNECTED


def get_duration(file: Path):
    try:
        r = subprocess.run([CONFIG.get("ffprobe", "ffprobe"), "-v", "error",
                            "-show_entries", "format=duration",
                            "-of", "default=noprint_wrappers=1:nokey=1", str(file)],
                           capture_output=True, text=True, timeout=30)
        return int(round(float((r.stdout or "0").strip())))
    except Exception:
        return None


def compute_stage():
    """Grąžina dabartinį konvejerio etapą + skambučio pradžios laiką (laikmačiui)."""
    now = time.time()
    if _call_phase == "active":
        return "in_call", _call_started      # tikrai pakelta
    if _call_phase == "dialing":
        return "dialing", None               # skambinama, dar nepakelta
    with _lock:
        transcribing = any(c.get("status") == "transcribing" for c in _calls)
    if transcribing:
        return "transcribing", None
    if _awaiting:
        return "pulling", None
    if _call_ended_at and (now - _call_ended_at) < 45:
        return "waiting", None
    return "idle", None


def read_phone_enabled():
    """Nuskaito telefono app'sės „enabled" jungiklį (per run-as, veikia debug app'sei)."""
    try:
        r = subprocess.run(adb_base() + ["shell", "run-as", "lt.callhub.dialer",
                           "cat", "shared_prefs/callhub.xml"],
                           capture_output=True, text=True, timeout=15)
        m = re.search(r'name="enabled"\s+value="(true|false)"', r.stdout or "")
        if m:
            return m.group(1) == "true"
    except Exception:
        pass
    return None   # nežinoma (traktuojam kaip įjungta)


def push_status(state: str = None) -> None:
    """Siunčia telefono app'sei būseną: kuris kompas valdo + ką daro."""
    if state is None:
        state, _ = compute_stage()
    try:
        subprocess.run(adb_base() + ["shell", "am", "broadcast", "-a", "lt.callhub.STATUS",
                       "-e", "computer", COMPUTER_NAME, "-e", "state", state,
                       "-n", "lt.callhub.dialer/.DialReceiver"],
                       capture_output=True, text=True, timeout=15)
    except Exception:
        pass


def dial(number: str) -> dict:
    global _call_phase, _call_ended_at
    if _blocked:
        return {"ok": False, "error": _block_reason or "Prieiga išjungta administratoriaus"}
    if _phone_enabled is False:
        return {"ok": False, "error": "Telefone CallHub IŠJUNGTAS — įjunk telefono app'sėje"}
    norm = normalize_number(number)
    if not norm:
        return {"ok": False, "error": f"neatpažintas numeris: {number}"}
    # MIUI blokuoja adb ACTION_CALL/input, tad skambinam per CallHub Dialer app'sę
    # (ji turi CALL_PHONE leidimą) — pasiekiam ją broadcast'u.
    def run_broadcast():
        cmd = adb_base() + ["shell", "am", "broadcast", "-a", "lt.callhub.DIAL",
                            "-e", "number", norm,
                            "-n", "lt.callhub.dialer/.DialReceiver"]
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=25)
        out = (r.stdout or "") + (r.stderr or "")
        return ("Broadcast completed" in out and r.returncode == 0), out

    adb_connect()
    try:
        ok, out = run_broadcast()
        if not ok:
            # Galbūt WiFi ryšys nukrito (telefonas užmigo) — persijungiam ir bandom dar kartą.
            adb_reconnect()
            ok, out = run_broadcast()
    except Exception as e:
        return {"ok": False, "error": str(e), "number": norm}
    if ok:
        _call_phase = "dialing"       # momentinis „Skambinama…" dar prieš adb patvirtinimą
        _call_ended_at = None
        with _lock:
            _pending.append({"number": norm, "ts": time.time()})
    return {"ok": ok, "number": norm, "adb": out.strip()}


def hangup() -> dict:
    """Nutraukia vykstantį skambutį per CallHub Dialer app'sę (TelecomManager.endCall)."""
    def run():
        cmd = adb_base() + ["shell", "am", "broadcast", "-a", "lt.callhub.HANGUP",
                            "-n", "lt.callhub.dialer/.DialReceiver"]
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=25)
        out = (r.stdout or "") + (r.stderr or "")
        return ("Broadcast completed" in out and r.returncode == 0), out

    adb_connect()
    try:
        ok, out = run()
        if not ok:
            adb_reconnect()
            ok, out = run()
    except Exception as e:
        return {"ok": False, "error": str(e)}
    return {"ok": ok, "adb": out.strip()}


def retranscribe(filename: str) -> dict:
    """Rankinis „transkribuoti iš naujo" — perleidžia įrašą per Whisper fone."""
    rec_dir = Path(CONFIG["recordings_dir"])
    f = rec_dir / filename
    if not f.exists():
        return {"ok": False, "error": "failas nerastas"}
    with _lock:
        entry = next((c for c in _calls if c.get("file") == filename), None)
        if entry:
            entry["status"] = "transcribing"
            entry["transcript"] = ""
            save_calls()

    def worker():
        transcript = transcribe(f)
        dur = get_duration(f)
        with _lock:
            e = next((c for c in _calls if c.get("file") == filename), None)
            if e:
                e["transcript"] = transcript
                e["status"] = "done"
                if e.get("duration_sec") is None:
                    e["duration_sec"] = dur
                e["transcribed_at"] = datetime.now().isoformat(timespec="seconds")
                save_calls()
        print(f"[callhub] iš naujo: {filename} ({len(transcript)} simb.)")

    threading.Thread(target=worker, daemon=True).start()
    return {"ok": True, "file": filename}


# ---- Transkripcija ----
def transcribe(path: Path) -> str:
    global _transcribe_progress
    _transcribe_progress = 0
    script = str(BASE / "transcribe_progress.py")
    cmd = [CONFIG["whisper_python"], script, str(path),
           "--language", CONFIG.get("language", "lt")]
    env = dict(os.environ)
    env["CALLHUB_HELPERS"] = str(Path(CONFIG["whisper_cwd"]) / "helpers")
    try:
        proc = subprocess.Popen(cmd, cwd=CONFIG.get("whisper_cwd"), env=env,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                text=True, encoding="utf-8", errors="replace")
    except Exception as e:
        return f"[transkripcijos klaida: {e}]"

    out_lines, err_tail = [], []

    def read_out():
        for line in proc.stdout:
            out_lines.append(line)

    def read_err():
        global _transcribe_progress
        for line in proc.stderr:
            m = re.match(r"PROGRESS (\d+)", line.strip())
            if m:
                _transcribe_progress = int(m.group(1))
            else:
                err_tail.append(line)

    to = threading.Thread(target=read_out, daemon=True); to.start()
    te = threading.Thread(target=read_err, daemon=True); te.start()
    try:
        proc.wait(timeout=1200)
    except subprocess.TimeoutExpired:
        proc.kill()
    to.join(timeout=3)
    te.join(timeout=3)
    _transcribe_progress = 100

    text = "".join(out_lines).strip()
    if not text:
        return f"[tuščia transkripcija; {''.join(err_tail).strip()[-200:]}]"
    return text


_PENDING_TTL = 900  # 15 min — seni „laukiantys" numeriai (skambučiai be įrašo) nurašomi


def prune_pending() -> None:
    now = time.time()
    with _lock:
        _pending[:] = [p for p in _pending if now - p["ts"] < _PENDING_TTL]


def match_number(file: Path) -> str:
    # Susivartojam vieną „laukiantį" numerį (kad skaitiklis atspindėtų tikrovę),
    # bet numerį imam iš failo vardo, jei jis ten yra (patikimiau).
    prune_pending()
    with _lock:
        popped = _pending.pop(0) if _pending else None
    n = extract_number_from_name(file.name)
    if n:
        return n
    if popped:
        return popped["number"]
    return "?"


def process_recording(file: Path) -> None:
    global _awaiting
    _awaiting = False
    number = match_number(file)
    # 1) iškart parodom „transkribuojama" (kad popup'e matytųsi progresas)
    entry = {
        "id": file.stem,
        "number": number,
        "file": file.name,
        "dialed_at": None,
        "transcribed_at": datetime.now().isoformat(timespec="seconds"),
        "duration_sec": get_duration(file),
        "transcript": "",
        "status": "transcribing",
    }
    with _lock:
        _calls.insert(0, entry)
        save_calls()
    print(f"[callhub] naujas įrašas: {file.name} (numeris: {number}) — transkribuoju…")
    # 2) transkribuojam ir atnaujinam
    transcript = transcribe(file)
    with _lock:
        entry["transcript"] = transcript
        entry["status"] = "done"
        entry["transcribed_at"] = datetime.now().isoformat(timespec="seconds")
        save_calls()
    print(f"[callhub] gatava: {file.name} ({len(transcript)} simb.)")


def adb_pull_loop() -> None:
    """Periodiškai per adb parsisiunčia naujus įrašus iš telefono į recordings/ (vietoj Syncthing)."""
    global _in_call, _call_started, _call_ended_at, _awaiting, _call_phase, _phone_enabled
    rec_local = Path(CONFIG["recordings_dir"])
    rec_local.mkdir(parents=True, exist_ok=True)
    remote = CONFIG.get("phone_call_rec", "/sdcard/MIUI/sound_recorder/call_rec")
    exts = tuple(CONFIG["audio_exts"])
    pulled = {f.name for f in rec_local.iterdir() if f.is_file()}
    while True:
        try:
            adb_connect()
            phase = call_phase()
            if phase == "unknown":
                phase = "active" if is_call_active() else "idle"
            prev = _call_phase
            _call_phase = phase
            if phase == "active" and _call_started is None:
                _call_started = time.time()          # laikmatis skaičiuoja nuo PAKĖLIMO
            if phase == "idle":
                if prev in ("active", "dialing"):
                    _call_ended_at = time.time()
                _call_started = None
            active = phase != "idle"
            _in_call = active

            r = subprocess.run(adb_base() + ["shell", "ls", "-1", remote],
                               capture_output=True, text=True, timeout=20)
            names = [n.strip() for n in (r.stdout or "").splitlines() if n.strip()]
            new = [n for n in names if n not in pulled and n.lower().endswith(exts)]
            if new and active:
                # Vyksta pokalbis — įrašas dar rašomas. Palaukiam, kol baigsis.
                pass
            elif new:
                for name in new:
                    dest = rec_local / name
                    pr = subprocess.run(adb_base() + ["pull", f"{remote}/{name}", str(dest)],
                                        capture_output=True, text=True, timeout=120)
                    if pr.returncode == 0:
                        pulled.add(name)
                        _awaiting = True   # parsisiųsta, laukia transkripcijos
                        print(f"[callhub] parsisiųsta iš telefono: {name}")
            _phone_enabled = read_phone_enabled()   # ar telefone CallHub įjungtas
            push_status()   # heartbeat į telefoną (kompas prisijungęs + būsena)
        except Exception as e:
            print(f"[callhub] adb-pull klaida: {e}")
        time.sleep(CONFIG.get("pull_seconds", 6))


def cleanup_recordings() -> None:
    """Ištrina įrašus senesnius nei retention_days (kompe + telefone). Tekstas (calls.json) LIEKA."""
    days = CONFIG.get("retention_days", 30)
    if not days or days <= 0:
        return
    cutoff = time.time() - days * 86400
    rec_dir = Path(CONFIG["recordings_dir"])
    exts = tuple(CONFIG["audio_exts"])
    removed = []
    for f in rec_dir.iterdir():
        try:
            if f.is_file() and f.suffix.lower() in exts and f.stat().st_mtime < cutoff:
                name = f.name
                f.unlink()
                removed.append(name)
        except Exception:
            pass
    for name in removed:   # tuos pačius ištrinti ir iš telefono
        try:
            subprocess.run(adb_base() + ["shell", "rm", "-f",
                           f"'/sdcard/MIUI/sound_recorder/call_rec/{name}'"],
                           capture_output=True, text=True, timeout=20)
        except Exception:
            pass
    if removed:
        print(f"[callhub] retention: ištrinta {len(removed)} įrašų > {days} d. (kompe + telefone)")


def cleanup_loop() -> None:
    while True:
        try:
            cleanup_recordings()
        except Exception as e:
            print(f"[callhub] cleanup klaida: {e}")
        time.sleep(3600)   # kas valandą


def self_update(zip_url: str) -> None:
    """Parsisiunčia naują helper+plėtinys zip, perrašo kodą (config/duomenys lieka) ir persileidžia."""
    import io
    import zipfile
    try:
        req = urllib.request.Request(zip_url, headers={
            "Accept": "application/vnd.github.raw", "User-Agent": "CallHub"})
        with urllib.request.urlopen(req, timeout=90) as resp:
            blob = resp.read()
        if blob[:1] == b"{":   # API grąžino base64 (be raw header)
            import base64
            blob = base64.b64decode(json.loads(blob.decode("utf-8"))["content"])
        preserve = {"config.json", "calls.json", "selected_device.json"}
        z = zipfile.ZipFile(io.BytesIO(blob))
        for name in z.namelist():
            if name.endswith("/") or ".." in name:
                continue
            if name.split("/")[-1] in preserve:   # vartotojo duomenų nekeičiam
                continue
            target = BASE / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(z.read(name))
        print("[callhub] ATNAUJINTA iki naujos versijos — persileidžiu")
        os._exit(42)   # start.bat ciklas paleis iš naujo su nauju kodu
    except Exception as e:
        print(f"[callhub] atnaujinimo klaida: {e}")


def read_installed_apk_version() -> int | None:
    """Telefone įdiegtos Dialer app'sės versionCode (per dumpsys). None jei nerasta/atjungta."""
    try:
        r = subprocess.run(adb_base() + ["shell", "dumpsys", "package", DIALER_PKG],
                           capture_output=True, text=True, timeout=15)
        m = re.search(r"versionCode=(\d+)", r.stdout)
        return int(m.group(1)) if m else None
    except Exception:
        return None


def apk_auto_update(data: dict) -> None:
    """TYLUS telefono APK atnaujinimas per adb (0 paspaudimų). Reikia „Install via USB" ON.
    Jei blokuota — nesustabdo sistemos, tik palieka žinutę /health."""
    global _apk_installed_ver, _apk_latest_ver, _apk_update_blocked, _apk_msg, _apk_last_tried
    try:
        latest = int(data.get("latest_apk_version") or 0)
        url = data.get("apk_url") or ""
        _apk_latest_ver = latest or None
        if not latest or not url:
            return
        installed = read_installed_apk_version()
        _apk_installed_ver = installed
        if installed is None:
            return   # app'sė dar neįdiegta rankiniu būdu (bootstrap) arba telefonas atjungtas
        if installed >= latest:
            _apk_update_blocked, _apk_msg = False, ""
            return
        if _apk_last_tried == latest and _apk_update_blocked:
            return   # jau bandėm šią versiją ir blokuota — nekartojam kas ciklą
        # 1) parsisiunčiam naują APK iš GitHub
        req = urllib.request.Request(url, headers={
            "Accept": "application/vnd.github.raw", "User-Agent": "CallHub"})
        with urllib.request.urlopen(req, timeout=120) as resp:
            blob = resp.read()
        if blob[:1] == b"{":   # API grąžino base64 JSON (be raw header) — atkoduojam
            import base64
            blob = base64.b64decode(json.loads(blob.decode("utf-8"))["content"])
        if len(blob) < 10000:
            _apk_msg = "APK parsisiuntimas nepavyko (per mažas)"
            return
        apk_path = BASE / "update_dialer.apk"
        apk_path.write_bytes(blob)
        # 2) tyliai įdiegiam per adb (WiFi)
        adb_connect()
        r = subprocess.run(adb_base() + ["install", "-r", str(apk_path)],
                           capture_output=True, text=True, timeout=180)
        out = (r.stdout or "") + (r.stderr or "")
        _apk_last_tried = latest
        if "Success" in out:
            _apk_update_blocked, _apk_msg = False, ""
            _apk_installed_ver = latest
            mark_apk_updated()
            print(f"[callhub] telefono APK ATNAUJINTA v{installed} -> v{latest} (tyliai)")
        elif "USER_RESTRICTED" in out or "INSTALL_FAILED_USER_RESTRICTED" in out:
            _apk_update_blocked = True
            _apk_msg = ("Telefone reikia įjungti 'Install via USB' (Developer options), "
                        "kad atnaujinimai eitų automatiškai be paspaudimų.")
            print("[callhub] APK diegimas blokuotas: reikia Install via USB")
        else:
            _apk_update_blocked = True
            _apk_msg = "APK diegimo klaida (žr. helper log)"
            print(f"[callhub] APK diegimo klaida: {out.strip()[:200]}")
    except Exception as e:
        print(f"[callhub] APK auto-update klaida: {e}")


def maybe_update(data: dict) -> None:
    try:
        latest = int(data.get("latest_helper_version") or 0)
        zurl = data.get("helper_zip_url") or ""
        if latest > HELPER_VERSION and zurl:
            print(f"[callhub] nauja versija {latest} > {HELPER_VERSION} — atnaujinu")
            self_update(zurl)
    except Exception:
        pass


def fleet_check() -> None:
    """Nuotolinis valdymas: patikrina fleet.json — ar šis brokeris aktyvus + atnaujinimai."""
    global _blocked, _block_reason, _last_fleet_ok
    url = CONFIG.get("fleet_url")
    if not url:
        return   # nekonfigūruota — neblokuojam
    bid = CONFIG.get("broker_id", "")
    try:
        req = urllib.request.Request(url, headers={
            "Accept": "application/vnd.github.raw",   # GitHub API grąžina šviežią turinį (be raw CDN kešo)
            "User-Agent": "CallHub",                  # GitHub API reikalauja User-Agent
            "Cache-Control": "no-cache",
        })
        with urllib.request.urlopen(req, timeout=15) as resp:
            body = resp.read().decode("utf-8")
        data = json.loads(body)
        if isinstance(data, dict) and data.get("encoding") == "base64":   # atsarginis: jei grąžino base64
            import base64
            data = json.loads(base64.b64decode(data["content"]).decode("utf-8"))
        _last_fleet_ok = time.time()
        if data.get("kill_all"):
            _blocked, _block_reason = True, "Visa sistema laikinai išjungta administratoriaus"
            return
        broker = (data.get("brokers") or {}).get(bid)
        if broker is None:
            _blocked, _block_reason = True, "Nerasta valdymo sąraše — kreipkis į administratorių"
        elif not broker.get("active", False):
            _blocked, _block_reason = True, "Prieiga išjungta administratoriaus"
        else:
            _blocked, _block_reason = False, ""
            apk_auto_update(data)   # telefono APK: tyliai įdiegia naujesnę per adb (jei Install via USB ON)
            maybe_update(data)      # helper: jei yra naujesnė versija — atsinaujina ir persileidžia
    except Exception:
        # Nepasiekiamas fleet.json — fail-closed PO grace periodo (kad neatjungtų interneto ir dirbtų amžinai)
        grace = CONFIG.get("fleet_grace_hours", 72) * 3600
        if _last_fleet_ok and (time.time() - _last_fleet_ok) > grace:
            _blocked, _block_reason = True, "Nepavyksta patikrinti prieigos (per ilgai be interneto)"


def fleet_check_loop() -> None:
    while True:
        try:
            fleet_check()
        except Exception as e:
            print(f"[callhub] fleet klaida: {e}")
        if _blocked:
            print(f"[callhub] BLOKUOTA: {_block_reason}")
        time.sleep(CONFIG.get("fleet_check_seconds", 120))


def watcher() -> None:
    rec_dir = Path(CONFIG["recordings_dir"])
    rec_dir.mkdir(parents=True, exist_ok=True)
    exts = tuple(CONFIG["audio_exts"])
    # Self-heal: paliekam tik SĖKMINGAI transkribuotus (done + netuščias tekstas),
    # o „įstrigusius" (transcribing / tuščias / klaida) išmetam, kad būtų perdaryti.
    with _lock:
        _calls[:] = [c for c in _calls
                     if c.get("status") == "done"
                     and (c.get("transcript") or "").strip()
                     and not (c.get("transcript") or "").startswith("[")]
        save_calls()
        done = {c["file"] for c in _calls}
    todo = [f.name for f in rec_dir.iterdir()
            if f.is_file() and f.suffix.lower() in exts and f.name not in done]
    if todo:
        print(f"[callhub] {len(todo)} netranskribuotų įrašų rasta — apdorosiu iš naujo")
    sizes: dict[str, int] = {}
    while True:
        try:
            for f in sorted(rec_dir.iterdir(), key=lambda p: p.stat().st_mtime if p.exists() else 0):
                if not f.is_file() or f.suffix.lower() not in exts or f.name in done:
                    continue
                try:
                    sz = f.stat().st_size
                except OSError:
                    continue
                if sizes.get(f.name) == sz and sz > 2000:   # dydis stabilus -> pilnai atkeltas
                    done.add(f.name)
                    sizes.pop(f.name, None)
                    process_recording(f)
                else:
                    sizes[f.name] = sz
        except Exception as e:
            print(f"[callhub] watcher klaida: {e}")
        time.sleep(CONFIG.get("poll_seconds", 4))


# ---- HTTP ----
class Handler(BaseHTTPRequestHandler):
    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Range")
        self.send_header("Access-Control-Expose-Headers", "Content-Length, Content-Range, Accept-Ranges")

    def _json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self._cors()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    def serve_audio(self):
        qs = parse_qs(urlparse(self.path).query)
        name = unquote(qs.get("file", [""])[0])
        if not name or "/" in name or "\\" in name or ".." in name:
            self._json({"error": "bad file"}, 400)
            return
        path = Path(CONFIG["recordings_dir"]) / name
        if not path.exists():
            self._json({"error": "not found"}, 404)
            return
        try:
            data = path.read_bytes()
        except Exception:
            self._json({"error": "read error"}, 500)
            return
        total = len(data)
        ctype = {".mp3": "audio/mpeg", ".wav": "audio/wav", ".aac": "audio/aac",
                 ".m4a": "audio/mp4", ".ogg": "audio/ogg", ".amr": "audio/amr"}.get(
                     path.suffix.lower(), "audio/mpeg")
        rng = self.headers.get("Range")
        if rng:   # dalinis turinys — būtinas laiko slinkčiai (seek)
            m = re.match(r"bytes=(\d*)-(\d*)", rng.strip())
            start = int(m.group(1)) if (m and m.group(1)) else 0
            end = int(m.group(2)) if (m and m.group(2)) else total - 1
            end = min(end, total - 1)
            if start > end or start >= total:
                start, end = 0, total - 1
            chunk = data[start:end + 1]
            self.send_response(206)
            self._cors()
            self.send_header("Content-Type", ctype)
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Range", f"bytes {start}-{end}/{total}")
            self.send_header("Content-Length", str(len(chunk)))
            self.end_headers()
            self.wfile.write(chunk)
        else:
            self.send_response(200)
            self._cors()
            self.send_header("Content-Type", ctype)
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Length", str(total))
            self.end_headers()
            self.wfile.write(data)

    def do_GET(self):
        if self.path.startswith("/calls"):
            rec_dir = Path(CONFIG["recordings_dir"])
            with _lock:
                out = []
                for c in _calls[:100]:
                    d = dict(c)
                    fn = c.get("file", "")
                    d["has_audio"] = bool(fn) and (rec_dir / fn).exists()
                    out.append(d)
            self._json(out)
        elif self.path.startswith("/audio"):
            self.serve_audio()
        elif self.path.startswith("/devices"):
            self._json({"devices": list_devices(), "selected": _selected_device})
        elif self.path.startswith("/health"):
            prune_pending()
            stage, started = compute_stage()
            elapsed = int(time.time() - started) if (stage == "in_call" and started) else None
            progress = _transcribe_progress if stage == "transcribing" else None
            devs = list_devices()
            connected = any(d["online"] and (not _selected_device or d["id"] == _selected_device)
                            for d in devs)
            sel = next((d for d in devs if d["id"] == _selected_device), None)
            # Kai neprijungtas — pridedam savidiagnostiką (kodėl + ką daryti). Greita: be tinklo skenavimo.
            diagnosis = None if connected else build_diagnosis(devs)
            self._json({"ok": True, "phone_connected": connected,
                        "device": _selected_device,
                        "device_model": sel["model"] if sel else _known_model,
                        "scanning": _scanning,
                        "phone_enabled": _phone_enabled,
                        "blocked": _blocked, "block_reason": _block_reason,
                        "retention_days": CONFIG.get("retention_days", 30),
                        "helper_version": HELPER_VERSION,
                        "helper_updated_at": _helper_updated_at,
                        "apk_version": _apk_installed_ver,
                        "apk_latest": _apk_latest_ver,
                        "apk_updated_at": _apk_updated_at,
                        "apk_update_blocked": _apk_update_blocked,
                        "apk_msg": _apk_msg,
                        "diagnosis": diagnosis,
                        "stage": stage, "elapsed": elapsed, "progress": progress,
                        "calls": len(_calls)})
        elif self.path == "/" or self.path.startswith("/test"):
            html = (
                "<!doctype html><meta charset=utf-8><title>CallHub testas</title>"
                "<body style='font-family:system-ui;max-width:620px;margin:40px auto;padding:0 16px'>"
                "<h1>CallHub testas</h1>"
                "<p>Numeris žemiau turi tapti <b>žaliai paspaudžiamas</b> (📞). "
                "Paspausk jį — Poco surinks, robotas atsakys.</p>"
                "<p style='font-size:24px'>Robotas: +370 600 79661</p>"
                "<p style='color:#888'>Po pokalbio (padėk ragelį) transkripcija atsiras "
                "plėtinio popup'e — spausk CallHub ikoną naršyklės viršuje.</p>"
                "</body>"
            ).encode("utf-8")
            self.send_response(200)
            self._cors()
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(html)))
            self.end_headers()
            self.wfile.write(html)
        else:
            self._json({"error": "not found"}, 404)

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0) or 0)
        try:
            data = json.loads(self.rfile.read(length) or b"{}")
        except Exception:
            data = {}
        if self.path.startswith("/dial"):
            result = dial(str(data.get("number", "")))
            self._json(result, 200 if result.get("ok") else 400)
        elif self.path.startswith("/hangup"):
            result = hangup()
            self._json(result, 200 if result.get("ok") else 400)
        elif self.path.startswith("/retranscribe"):
            result = retranscribe(str(data.get("file", "")))
            self._json(result, 200 if result.get("ok") else 400)
        elif self.path.startswith("/select"):
            set_selected_device(str(data.get("id", "")))
            adb_connect()
            self._json({"ok": True, "selected": _selected_device})
        elif self.path.startswith("/wireless"):
            self._json(make_wireless(str(data.get("serial", ""))))
        elif self.path.startswith("/connect"):
            self._json(connect_ip(str(data.get("ip", ""))))
        elif self.path.startswith("/rescan"):
            self._json(scan_and_reconnect())
        elif self.path.startswith("/diagnose"):
            self._json(diagnose_active())
        elif self.path.startswith("/retention"):
            try:
                days = int(data.get("days", 30))
            except Exception:
                days = 30
            days = max(0, min(3650, days))
            CONFIG["retention_days"] = days   # veikia iškart (cleanup skaito CONFIG)
            try:
                (BASE / "config.json").write_text(
                    json.dumps(CONFIG, ensure_ascii=False, indent=2), encoding="utf-8")
            except Exception:
                pass
            self._json({"ok": True, "retention_days": days})
        else:
            self._json({"error": "not found"}, 404)

    def log_message(self, *args):
        pass   # tyla; savo log'us spausdinam patys


def main() -> None:
    load_calls()
    load_selected_device()
    load_version_state()
    threading.Thread(target=watcher, daemon=True).start()
    threading.Thread(target=adb_pull_loop, daemon=True).start()
    threading.Thread(target=cleanup_loop, daemon=True).start()
    threading.Thread(target=fleet_check_loop, daemon=True).start()
    threading.Thread(target=connection_loop, daemon=True).start()
    port = CONFIG.get("port", 8199)
    srv = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    print(f"[callhub] veikia: http://127.0.0.1:{port}")
    print(f"[callhub] adb: {CONFIG['adb_path']}")
    print(f"[callhub] įrašų aplankas: {CONFIG['recordings_dir']}")
    print(f"[callhub] adb devices:\n{adb_devices()}")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\n[callhub] stabdau.")


if __name__ == "__main__":
    main()
