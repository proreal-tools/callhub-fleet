// CallHub service worker: tarpininkas tarp puslapio/skydelio ir vietinio serverio.
const HUB = "http://127.0.0.1:8199";

// Paspaudus įrankio ikoną — atidaryti šoninį skydelį (jis lieka atidarytas
// dirbant su puslapiu, skirtingai nei popup, kuris užsidaro praradus fokusą).
if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
}

async function dial(number) {
  const r = await fetch(HUB + "/dial", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ number })
  });
  return r.json();
}

async function hangup() {
  const r = await fetch(HUB + "/hangup", { method: "POST" });
  return r.json();
}

// ---- AI: naudojam VIENĄ chatą (tą patį tab'ą), kad nesikauptų daug pokalbių ----
function aiBase(provider) {
  if (provider === "claude") return "https://claude.ai/new";
  if (provider === "gemini") return "https://gemini.google.com/app";
  return "https://chatgpt.com/";
}

// Tab'ą sekam KIEKVIENAM modeliui atskirai (kad grįžus prie modelio reuse'intų jo langą)
async function getTabs() {
  const { aiTabs } = await chrome.storage.session.get("aiTabs");
  return aiTabs || {};
}
async function setTab(provider, id) {
  const tabs = await getTabs();
  tabs[provider] = id;
  await chrome.storage.session.set({ aiTabs: tabs });
}
async function clearTab(provider) {
  const tabs = await getTabs();
  delete tabs[provider];
  await chrome.storage.session.set({ aiTabs: tabs });
}

function waitForComplete(tabId, timeout = 15000) {
  return new Promise((resolve) => {
    const t = setTimeout(() => { chrome.tabs.onUpdated.removeListener(cb); resolve(false); }, timeout);
    function cb(id, info) {
      if (id === tabId && info.status === "complete") {
        clearTimeout(t); chrome.tabs.onUpdated.removeListener(cb); resolve(true);
      }
    }
    chrome.tabs.onUpdated.addListener(cb);
  });
}

async function aiImprove(prompt, provider, forceNew) {
  const tabs = await getTabs();
  let tab = null;
  // Naudojam ŠIO modelio tab'ą, jei jis gyvas
  if (!forceNew && tabs[provider] != null) {
    try { tab = await chrome.tabs.get(tabs[provider]); } catch (e) { tab = null; }
  }
  if (tab) {
    try {
      const res = await chrome.tabs.sendMessage(tab.id, { type: "callhub-insert", text: prompt });
      return { ok: true, injected: !!(res && res.ok), reused: true };
    } catch (e) {
      // tab'as dingo arba be skripto — krentam žemyn ir kuriam naują
    }
  }
  // Naujas tab'as FONE (naujas šio modelio chatas)
  const created = await chrome.tabs.create({ url: aiBase(provider), active: false });
  await setTab(provider, created.id);
  await waitForComplete(created.id);
  await new Promise((r) => setTimeout(r, 2500)); // palaukiam kol SPA atsivaizduos (fone – ilgiau)
  try {
    const res = await chrome.tabs.sendMessage(created.id, { type: "callhub-insert", text: prompt });
    return { ok: true, injected: !!(res && res.ok), reused: false };
  } catch (e) {
    return { ok: true, injected: false, reused: false };
  }
}

async function aiOpen(provider) {
  const tabs = await getTabs();
  if (tabs[provider] != null) {
    try {
      const tab = await chrome.tabs.get(tabs[provider]);
      await chrome.tabs.update(tab.id, { active: true });
      try { await chrome.windows.update(tab.windowId, { focused: true }); } catch (e) {}
      return { ok: true, existed: true };
    } catch (e) { /* dingo */ }
  }
  const created = await chrome.tabs.create({ url: aiBase(provider), active: true });
  await setTab(provider, created.id);
  return { ok: true, existed: false };
}

// Iš content script'o (paspaudus numerį / „Baigti")
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "dial") {
    dial(msg.number)
      .then(res => sendResponse(res))
      .catch(err => sendResponse({ ok: false, error: String(err) }));
    return true; // async
  }
  if (msg && msg.type === "hangup") {
    hangup()
      .then(res => sendResponse(res))
      .catch(err => sendResponse({ ok: false, error: String(err) }));
    return true; // async
  }
  if (msg && msg.type === "aiImprove") {
    aiImprove(msg.prompt, msg.provider, msg.forceNew)
      .then(res => sendResponse(res))
      .catch(err => sendResponse({ ok: false, error: String(err) }));
    return true; // async
  }
  if (msg && msg.type === "aiNewChat") {
    chrome.storage.session.remove(["aiTabId", "aiProvider"])
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: true }));
    return true; // async
  }
  if (msg && msg.type === "aiOpen") {
    aiOpen(msg.provider)
      .then(res => sendResponse(res))
      .catch(err => sendResponse({ ok: false, error: String(err) }));
    return true; // async
  }
});

// Dešinio klik meniu ant pažymėto teksto
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "callhub-dial",
    title: "📞 Skambinti (Poco): %s",
    contexts: ["selection"]
  });
});

chrome.contextMenus.onClicked.addListener((info) => {
  if (info.menuItemId === "callhub-dial" && info.selectionText) {
    dial(info.selectionText).catch(() => {});
  }
});
