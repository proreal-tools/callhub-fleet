"""Transkripcija su progresu. Naudoja tą patį video-use venv faster-whisper modelį,
bet, apdorodama segmentus, praneša progresą į stderr (PROGRESS <pct>), o galutinį
tekstą spausdina į stdout. CallHub helper'is skaito progresą realiu laiku.
"""

from __future__ import annotations

import argparse
import os
import sys
import tempfile
import threading
import time
from pathlib import Path

# Prisikabinam video-use/helpers, kad rastume jų `transcribe` modulį (modelio
# užkrovimas + CUDA DLL paruošimas). Kelią paduoda helper'is per env.
_helpers = os.environ.get("CALLHUB_HELPERS")
if _helpers and _helpers not in sys.path:
    sys.path.insert(0, _helpers)

from transcribe import DEFAULT_MODEL, extract_audio, load_model  # noqa: E402


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("media", type=Path)
    ap.add_argument("--language", default="lt")
    ap.add_argument("--model", default=DEFAULT_MODEL)
    args = ap.parse_args()

    media = args.media.resolve()
    if not media.exists():
        sys.exit(f"not found: {media}")
    language = None if args.language == "auto" else args.language

    with tempfile.TemporaryDirectory() as tmp:
        wav = Path(tmp) / "audio.wav"
        extract_audio(media, wav)
        # Modelio krovimo fazė: lėtai judinam juostą 0→20 %, kad matytųsi progresas
        loading = {"on": True}

        def load_ticker():
            pct = 0
            while loading["on"] and pct < 20:
                time.sleep(1)
                pct += 2
                print(f"PROGRESS {min(20, pct)}", file=sys.stderr, flush=True)

        th = threading.Thread(target=load_ticker, daemon=True)
        th.start()
        model = load_model(args.model)
        loading["on"] = False

        segments, info = model.transcribe(
            str(wav), language=language, vad_filter=False,
            beam_size=5, condition_on_previous_text=True,
        )
        total = float(getattr(info, "duration", 0) or 0)
        parts = []
        for seg in segments:
            t = (seg.text or "").strip()
            if t:
                parts.append(t)
            if total > 0:
                pct = 20 + int(seg.end / total * 79)   # dekodavimas: 20→99 %
                print(f"PROGRESS {max(21, min(99, pct))}", file=sys.stderr, flush=True)
        text = " ".join(parts).strip()

    print("PROGRESS 100", file=sys.stderr, flush=True)
    print(text)


if __name__ == "__main__":
    main()
