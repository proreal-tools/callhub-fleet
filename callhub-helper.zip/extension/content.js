// CallHub content script: aptinka telefono numerius bet kuriame puslapyje ir
// paverčia juos paspaudžiamais "skambinti" mygtukais.

(function () {
  const CANDIDATE = /(?:\+?\d[\d\s().\-]{6,}\d)/g;

  function normalize(raw) {
    let s = (raw || "").replace(/[^\d+]/g, "");
    if (s.startsWith("00")) s = "+" + s.slice(2);
    const digits = s.replace(/\D/g, "");
    if (s.startsWith("+")) return digits.length >= 8 && digits.length <= 15 ? s : null;
    if (digits.length === 9 && digits.startsWith("8")) return "+370" + digits.slice(1);
    if (digits.length === 11 && digits.startsWith("370")) return "+" + digits;
    return null;
  }

  function toast(text, ok) {
    const t = document.createElement("div");
    t.className = "callhub-toast" + (ok === false ? " callhub-err" : "");
    t.textContent = text;
    document.body.appendChild(t);
    setTimeout(() => t.classList.add("callhub-show"), 10);
    setTimeout(() => { t.classList.remove("callhub-show"); setTimeout(() => t.remove(), 300); }, 3000);
  }

  // Saugus siuntimas: jei plėtinys ką tik perkrautas, senas skriptas puslapyje
  // gauna „context invalidated" — tada tik paprašom perkrauti puslapį.
  function safeSend(msg, cb) {
    try {
      if (!chrome.runtime || !chrome.runtime.id) throw new Error("invalidated");
      chrome.runtime.sendMessage(msg, cb);
    } catch (e) {
      toast("⚠️ Perkrauk puslapį (F5) — plėtinys buvo atnaujintas", false);
    }
  }

  function call(number, normalized) {
    toast("📞 Skambinu " + normalized + "…");
    safeSend({ type: "dial", number }, (res) => {
      if (chrome.runtime.lastError || !res) {
        toast("⚠️ CallHub serveris nepasiekiamas (paleisk start.bat)", false);
      } else if (!res.ok) {
        toast("⚠️ " + (res.error || "nepavyko surinkti"), false);
      }
      // skambutis paleistas — „Baigti skambutį" dabar CallHub skydelyje (ne ant puslapio)
    });
  }

  function hangup() {
    safeSend({ type: "hangup" }, (res) => {
      if (chrome.runtime.lastError || !res || !res.ok) {
        toast("⚠️ nepavyko nutraukti (bandyk dar kartą)", false);
      } else {
        toast("📴 Skambutis nutrauktas");
      }
    });
    removeHangupButton();
  }

  function showHangupButton() {
    if (document.getElementById("callhub-hangup")) return;
    const btn = document.createElement("div");
    btn.id = "callhub-hangup";
    btn.className = "callhub-hangup";
    btn.textContent = "📴 Baigti skambutį";
    btn.addEventListener("click", hangup);
    document.body.appendChild(btn);
    setTimeout(removeHangupButton, 5 * 60 * 1000); // saugiklis
  }

  function removeHangupButton() {
    const b = document.getElementById("callhub-hangup");
    if (b) b.remove();
  }

  function makeChip(normalized, raw) {
    const el = document.createElement("span");
    el.className = "callhub-num";
    el.textContent = raw;
    el.title = "Skambinti per Poco: " + normalized;
    el.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      call(raw, normalized);
    });
    return el;
  }

  const SKIP = new Set(["A", "SCRIPT", "STYLE", "TEXTAREA", "INPUT", "SELECT", "BUTTON", "NOSCRIPT"]);

  function skipNode(node) {
    let p = node.parentElement;
    while (p) {
      if (SKIP.has(p.tagName)) return true;
      if (p.isContentEditable) return true;
      if (p.classList && p.classList.contains("callhub-num")) return true;
      p = p.parentElement;
    }
    return false;
  }

  function processTextNode(node) {
    const text = node.nodeValue;
    if (!text || text.length < 8 || !/\d/.test(text)) return;
    CANDIDATE.lastIndex = 0;
    let m, matches = [];
    while ((m = CANDIDATE.exec(text)) !== null) {
      const norm = normalize(m[0]);
      if (norm) matches.push({ start: m.index, end: m.index + m[0].length, raw: m[0], norm });
    }
    if (!matches.length) return;
    const frag = document.createDocumentFragment();
    let last = 0;
    for (const mm of matches) {
      if (mm.start > last) frag.appendChild(document.createTextNode(text.slice(last, mm.start)));
      frag.appendChild(makeChip(mm.norm, mm.raw));
      last = mm.end;
    }
    if (last < text.length) frag.appendChild(document.createTextNode(text.slice(last)));
    node.parentNode.replaceChild(frag, node);
  }

  // Perima esamas <a href="tel:..."> nuorodas ir paverčia CallHub skambinimu.
  function hookTelLink(a) {
    if (!a || a.dataset.callhubTel) return;
    const raw = decodeURIComponent((a.getAttribute("href") || "").replace(/^tel:/i, "")).trim();
    const norm = normalize(raw);
    if (!norm) return;
    a.dataset.callhubTel = "1";
    a.classList.add("callhub-num");
    a.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      call(raw, norm);
    }, true);
  }

  function linkifyTelLinks(root) {
    if (root && root.matches && root.matches('a[href^="tel:" i]')) hookTelLink(root);
    const scope = (root && root.querySelectorAll) ? root : document;
    let links;
    try { links = scope.querySelectorAll('a[href^="tel:" i]'); } catch (e) { return; }
    links.forEach(hookTelLink);
  }

  function scan(root) {
    if (!root || !document.body) return;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(n) {
        if (skipNode(n)) return NodeFilter.FILTER_REJECT;
        return /\d/.test(n.nodeValue || "") ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      }
    });
    const nodes = [];
    let n;
    while ((n = walker.nextNode())) nodes.push(n);
    nodes.forEach(processTextNode);
    linkifyTelLinks(root);
  }

  // Pradinis skenavimas
  scan(document.body);

  // Naujai atsiradęs turinys (throttled)
  let pending = false;
  const obs = new MutationObserver((muts) => {
    if (pending) return;
    pending = true;
    setTimeout(() => {
      pending = false;
      for (const mu of muts) {
        for (const node of mu.addedNodes) {
          if (node.nodeType === 1) scan(node);
          else if (node.nodeType === 3) processTextNode(node);
        }
      }
    }, 500);
  });
  if (document.body) obs.observe(document.body, { childList: true, subtree: true });
})();
