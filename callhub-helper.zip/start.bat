@echo off
title CallHub
cd /d "%~dp0"
if exist stop.flag del stop.flag
:loop
if exist stop.flag ( del stop.flag & goto end )
python callhub.py
if exist stop.flag ( del stop.flag & goto end )
rem 42 = self-update; bet koks kitas kritimas -> irgi persileidžiam po ~5s
ping -n 6 127.0.0.1 >nul
goto loop
:end
