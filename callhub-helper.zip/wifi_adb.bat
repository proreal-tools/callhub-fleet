@echo off
REM Prijungia Poco per WiFi (belaidis adb). Paleisk, jei helper nebemato telefono
REM (pvz. po telefono perkrovimo). Jei po perkrovimo neveiks - prijunk USB kabeli
REM VIENAM kartui ir paleisk si faila dar karta.
set "ADB=C:\Users\linas\AndroidBuild\android-sdk\platform-tools\adb.exe"
"%ADB%" tcpip 5555 2>nul
timeout /t 2 >nul
"%ADB%" connect 192.168.0.5:5555
"%ADB%" devices
echo.
echo Jei sarase matai "192.168.0.5:5555  device" - belaidis rysys veikia.
pause
